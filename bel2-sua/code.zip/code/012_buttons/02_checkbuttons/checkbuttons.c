/*! Simple check button demo application. Illustrates how to check the state of
 *  check buttons and how to make them sensitive or insensitive respectively.
 *  The application uses a box container to layout the buttons and the label.
 *  The latter is used to output state information.
 *
 *  USAGE:
 *  Click one of the check buttons using the mouse or TAB + SPACE combination.
 */
#include <gtk/gtk.h>

// struct that collects all widgets we will use in various callbacks
struct my_widgets {
	GtkWidget *check1;
	GtkWidget *check2;
	GtkWidget *label;
};

static void check1_toggled (GtkWidget *widget, gpointer user_data);
static void check2_toggled (GtkWidget *widget, gpointer user_data);

/*! callback when check button 1 is toggled */
static void
check1_toggled (GtkWidget *widget, gpointer user_data)
{
	struct my_widgets *w = (struct my_widgets*) user_data;

	if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (w->check1))) {
		gtk_widget_set_sensitive (GTK_WIDGET (w->check2), TRUE);
		gtk_label_set_label (GTK_LABEL (w->label), "1: check 2: sensitive");
	} else {
		gtk_widget_set_sensitive (GTK_WIDGET (w->check2), FALSE);
		gtk_label_set_label (GTK_LABEL (w->label), "1: off   2: insensitive");
	}
}

/*! callback when check button 2 is toggled */
static void
check2_toggled (GtkWidget *widget, gpointer user_data)
{
	struct my_widgets *w = (struct my_widgets*) user_data;

	if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (w->check2)))
		gtk_label_set_label (GTK_LABEL (w->label), "1: check 2: check");
	else
		gtk_label_set_label (GTK_LABEL (w->label), "1: check 2: off");
}

/* app activate callback - creates the window */
static void
activate (GtkApplication* app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *box;

	struct my_widgets *w = (struct my_widgets*) user_data;

	/* create the window and associate a title and an icon */
	window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (window), "Check Buttons");
	gtk_container_set_border_width (GTK_CONTAINER (window), 10);
	gtk_window_set_default_icon_from_file ("button.png", NULL);

	box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 5);
	gtk_container_add (GTK_CONTAINER (window), box);

	/* create new check buttons and a label */
	w->check1 = gtk_check_button_new_with_label ("I am the main option.");
	gtk_box_pack_start (GTK_BOX (box), w->check1, FALSE, TRUE, 0);
	g_signal_connect (w->check1, "toggled",
			  G_CALLBACK (check1_toggled), (gpointer) w);
	w->check2 = gtk_check_button_new_with_label ("I rely on the other guy.");
	gtk_box_pack_start (GTK_BOX (box), w->check2, FALSE, TRUE, 0);
	g_signal_connect (w->check2, "toggled",
			  G_CALLBACK (check2_toggled), (gpointer) w);
	/* only enable the second check button when the first is enabled. */
	gtk_widget_set_sensitive (w->check2, FALSE);

	w->label = gtk_label_new ("1: off  2: inactive");
	gtk_box_pack_start (GTK_BOX (box), w->label, FALSE, TRUE, 0);
	/* */
	gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	/* we need some memory for the widgets struct */
	struct my_widgets *w = g_malloc (sizeof (struct my_widgets));

	/* create a threaded application */
	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer) w);
	/* run the application -> emits an "activate" signal */
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	/* free the memory for the widgets struct */
	g_free (w);
	w = NULL;

	return status;
}
/*! EOF */
