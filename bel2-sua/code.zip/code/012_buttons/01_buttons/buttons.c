/*! Simple button demo application. Creates a fixed sized window, adds a box
 *  with a label and two buttons and installs a callback that processes button
 *  clicks either via the mouse or the keyboard. Also shows how to modify the
 *  label of a button.
 *
 *  USAGE:
 *  Click one of the buttons using the mouse.
 *  Press Alt+B to click the lower button using the keyboard.
 *  Press the Spacebar to click the default (upper) button.
 */
#include <gtk/gtk.h>
#include <glib/gprintf.h>

static void
print_button (GtkButton *button, gpointer data)
{
  gchar string[15] = "";
  static gint lval = 0, mval = 0;

  if(g_strcmp0("lb",(gchar*)data)==0)
  {
    g_snprintf(string,10,"Label %d",++lval);
    gtk_button_set_label(GTK_BUTTON(button), string);
    g_print("You pressed button %s times.\n",string);
  }
  else
    g_print("You pressed button Memnonic %d times.\n",++mval);
}

// app activate callback - creates the window
static void
activate (GtkApplication* app, gpointer user_data)
{
  GtkWidget *window;
  GtkWidget *box;
  GtkWidget *label;
  GtkWidget *fixed;
  GtkWidget *lbutton;
  GtkWidget *mbutton;

	// create the window and associate a title and an icon
	window = gtk_application_window_new (app);
  gtk_window_set_title(GTK_WINDOW(window), "Button Demo");
  gtk_window_set_default_icon_from_file("button.png", NULL);
  gtk_window_set_default_size(GTK_WINDOW(window), 200, 80);     
  gtk_window_set_resizable(GTK_WINDOW(window), FALSE); 
  gtk_container_set_border_width(GTK_CONTAINER(window), 5);
  
  /* Create a box and add it to the window */
  box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
  gtk_container_add(GTK_CONTAINER(window), box);
  
  /* Create a label and add it to the box */
  label = gtk_label_new("Click the buttons and\ncheck the CMD line");
  gtk_box_pack_start(GTK_BOX(box), label, FALSE, FALSE, 0);
  
  /* Create a fixed container and add it to the box */
  fixed = gtk_fixed_new();
  gtk_box_pack_start(GTK_BOX(box), fixed, FALSE, FALSE, 0);

  /* Create new buttons */
  lbutton = gtk_button_new_with_label("Label Button");
  gtk_widget_set_size_request(lbutton, 150, 25);
  gtk_fixed_put(GTK_FIXED(fixed), lbutton, 0, 0); 
  g_signal_connect(GTK_BUTTON(lbutton), "clicked",
                   G_CALLBACK(print_button), "lb");
  gtk_widget_set_tooltip_text(lbutton, "Left-click to change the button label");
  gtk_widget_grab_focus(lbutton);                      

  mbutton = gtk_button_new_with_mnemonic("Memnonic _Button");
  gtk_widget_set_size_request(mbutton, 150, 25);
  gtk_fixed_put(GTK_FIXED (fixed), mbutton, 0, 40); 
  g_signal_connect(GTK_BUTTON (mbutton), "clicked",
                   G_CALLBACK (print_button), "mb");
  gtk_widget_set_tooltip_text(mbutton, "Press Alt+B or Left-click");
  /**/

  /* now show all created widgets */
  gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;

	// create a threaded application
	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	return status;
}
/** EOF */
