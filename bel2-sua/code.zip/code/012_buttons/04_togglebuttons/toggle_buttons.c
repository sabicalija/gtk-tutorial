/*! Simple toggle button demo application.
 *
 *  USAGE:
 *  Click the button.
 */
#include <gtk/gtk.h>

void toggle_button_callback (GtkWidget *widget, gpointer data);

/*! toggle button callback */
void
toggle_button_callback (GtkWidget *widget, gpointer data)
{
	if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget)))
		gtk_label_set_label (GTK_LABEL (data), "Pressed");
	else
		gtk_label_set_label (GTK_LABEL (data), "Not Pressed");
}

/* app activate callback - creates the window */
static void
activate (GtkApplication* app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *box;
	GtkWidget *sep;
	GtkWidget *label;
	GtkWidget *but;

	/* create the window and associate a title and an icon */
	window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (window), "Toggle Buttons");
	gtk_window_set_default_size (GTK_WINDOW (window), 80, 50);
	gtk_window_set_default_icon_from_file ("button.png", NULL);

	/* create a box where to store the toggle button */
	box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add (GTK_CONTAINER (window), box);
	gtk_container_set_border_width (GTK_CONTAINER (window), 10);
	/* create new buttons */
	but = gtk_toggle_button_new_with_label ("Toggle Button");
	gtk_box_pack_start (GTK_BOX (box), but, FALSE, TRUE, 0);
	sep = gtk_separator_new (GTK_ORIENTATION_VERTICAL);
	gtk_box_pack_start (GTK_BOX (box), sep, FALSE, TRUE, 5);
	label = gtk_label_new ("Not Pressed");
	gtk_box_pack_start (GTK_BOX (box), label, FALSE, TRUE, 0);
	g_signal_connect (GTK_BUTTON (but), "toggled",
			  G_CALLBACK (toggle_button_callback), (gpointer) label);
	/**/

	gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;

	/* create a threaded application */
	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
	/* run the application -> emits an "activate" signal */
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	return status;
}
/*! EOF */
