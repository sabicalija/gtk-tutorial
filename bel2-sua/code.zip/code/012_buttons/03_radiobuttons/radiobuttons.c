/*! Simple radio button demo application. Illustrates how to check the state of
 *  radio buttons where only one can be active at a time.
 *
 *  USAGE:
 *  Select a radio button and press the button below.
 *
 *  M. Horauer
 */
#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

/* define the number of radio buttons */
#define NB 3

/* struct that collects all widgets we will use in various callbacks */
struct my_widgets {
	GtkWidget *radio[NB];
	GtkWidget *label;
};

static void read_rb (GtkWidget *button, gpointer *user_data);

/* callback to demonstrate the readout of the radio button states */
static void
read_rb (GtkWidget *button, gpointer *user_data)
{
	gboolean r[NB];
	gchar *string = g_malloc (50);

	struct my_widgets *w = (struct my_widgets*) user_data;

	for (gint i = 0; i < NB; i++) {
		r[i] = FALSE;
	}
	for (gint i = 0; i < NB; i++) {
		r[i] = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (w->radio[i]));
	}
	for (gint i = 0; i < NB; i++) {
		if (r[i] == TRUE) {
			g_sprintf (string, "Radio Button %d is active", i + 1);
			gtk_label_set_label (GTK_LABEL (w->label), string);
		}
	}
	g_free (string);
}

/* app activate callback - creates the window */
static void
activate (GtkApplication* app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *box;
	GtkWidget *sep;

	struct my_widgets *w = (struct my_widgets*) user_data;

	/* create the window and associate a title and an icon */
	window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (window), "Radio Buttons");
	gtk_window_set_default_size (GTK_WINDOW (window), 300, 50);
	gtk_container_set_border_width (GTK_CONTAINER (window), 10);
	gtk_window_set_default_icon_from_file ("button.png", NULL);

	/* create a box container where to place all the following widgets */
	box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 5);
	gtk_container_add (GTK_CONTAINER (window), box);
	/* create 3 radio buttons where the second two join the group of the first */
	w->radio[0] = gtk_radio_button_new_with_label (NULL, "Radio Button 1");
	{
		gchar *string = g_malloc (50);
		for (gint i = 1; i < NB; i++) {
			g_sprintf (string, "Radio Button %d", i + 1);
			w->radio[i] = gtk_radio_button_new_with_label_from_widget (
					      GTK_RADIO_BUTTON (w->radio[0]), string);
		}
		g_free (string);
	}
	for (gint i = 0; i < NB; i++) {
		gtk_box_pack_start (GTK_BOX (box), w->radio[i], FALSE, TRUE, 0);
	}
	/* add a separator */
	sep = gtk_separator_new (GTK_ORIENTATION_VERTICAL);
	gtk_box_pack_start (GTK_BOX (box), sep, FALSE, TRUE, 5);
	/* add a label to output the status */
	w->label = gtk_label_new ("Radio Button 1 is active");
	gtk_box_pack_start (GTK_BOX (box), w->label, FALSE, TRUE, 0);
	for (gint i = 0; i < NB; i++) {
		g_signal_connect (G_OBJECT (w->radio[i]), "toggled",
				  G_CALLBACK (read_rb), (gpointer) w);
	}
	/* */
	gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	/* we need some memory for the widgets struct */
	struct my_widgets *w = g_malloc (sizeof (struct my_widgets));

	/* create a threaded application */
	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer) w);
	/* run the application -> emits an "activate" signal */
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	/* free the memory for the widgets struct */
	g_free (w);
	w = NULL;

	return status;
}
/*! EOF */
