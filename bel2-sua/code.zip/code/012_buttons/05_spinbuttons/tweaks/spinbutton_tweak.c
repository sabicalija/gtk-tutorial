/*!
 * Simple Spinbutton Demo Application
 *
 * Version 1
 * M. Horauer
 *
 * Build instructions:
 * gcc spinbutton.c `pkg-config --cflags --libs gtk+-3.0` -o sb -Wall -g
 */
#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

// struct that collects all widgets we will use in various callbacks
struct my_widgets {
	GtkWidget *date_set_label;
	GtkWidget *year;
	GtkWidget *month;
	GtkWidget *day;
};

static void
ok_clicked (GtkWidget *widget, gpointer user_data)
{
	gint y;
	gint m;
	gint d;
	gint n;
	gchar *str = g_malloc (30);
	struct my_widgets *wid = (struct my_widgets *) user_data;

	y = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (wid->year));
	m = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (wid->month));
	d = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (wid->day));
	n = g_sprintf (str, "Date Set: %04d-%02d-%02d", y, m, d);
	g_assert (n < 30);
	gtk_label_set_text (GTK_LABEL (wid->date_set_label), str);
	g_free (str);
}

static void
clr_clicked (GtkWidget *widget, gpointer user_data)
{
	struct my_widgets *wid = (struct my_widgets *) user_data;

	gtk_label_set_text (GTK_LABEL (wid->date_set_label), "Date Set: YYYY-MM-DD");
}

// app activate callback - creates the window
static void
activate (GtkApplication* app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *grid;
	GtkWidget *date_label;
	GtkWidget *clr_button, *ok_button;
	struct my_widgets *wid = (struct my_widgets*) user_data;

	window = gtk_application_window_new (app);
	gtk_window_set_default_size (GTK_WINDOW (window), 385, 80);
	gtk_window_set_resizable (GTK_WINDOW (window), FALSE);
	gtk_window_set_title (GTK_WINDOW (window), "Spinbutton Demo");
	gtk_container_set_border_width (GTK_CONTAINER (window), 5);
	grid = gtk_grid_new();
	gtk_container_add (GTK_CONTAINER (window), grid);
	gtk_grid_set_row_homogeneous (GTK_GRID (grid), TRUE);
	gtk_grid_set_row_spacing (GTK_GRID (grid), 5);
	gtk_grid_set_column_spacing (GTK_GRID (grid), 5);
	wid->date_set_label = gtk_label_new ("Date Set: XXXX-YY-ZZ");
	gtk_grid_attach (GTK_GRID (grid), wid->date_set_label, 0, 0, 4, 1);

	date_label = gtk_label_new ("Date:");
	// a high-level approach to tweak the 'x-align' property
	gtk_label_set_xalign (GTK_LABEL (date_label), 1.0);
	//
	gtk_grid_attach (GTK_GRID (grid), date_label, 0, 1, 1, 1);
	gtk_widget_set_size_request (date_label, 90, -1);
	// CREATE the SPIN BUTTONS
	wid->year = gtk_spin_button_new_with_range (2000, 2050, 1);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (wid->year), 2017);
	gtk_grid_attach (GTK_GRID (grid), GTK_WIDGET (wid->year), 1, 1, 1, 1);
	gtk_widget_set_size_request (wid->year, 90, -1);
	wid->month = gtk_spin_button_new_with_range (1, 12, 1);
	gtk_grid_attach (GTK_GRID (grid), GTK_WIDGET (wid->month), 2, 1, 1, 1);
	gtk_widget_set_size_request (wid->month, 90, -1);
	// a high-level approach to tweak the 'x-align' property
	gtk_entry_set_alignment(GTK_ENTRY(wid->month), 1.0);
	//
	wid->day = gtk_spin_button_new_with_range (1, 31, 1);
	// a low-level approach to tweak the 'x-align' property
	GValue spinalign = G_VALUE_INIT;
	g_value_init (&spinalign, G_TYPE_FLOAT);
	g_value_set_float (&spinalign, 1.0);
	g_object_set_property (G_OBJECT (wid->day), "xalign", &spinalign);
	g_value_unset (&spinalign);
	//
	gtk_grid_attach (GTK_GRID (grid), GTK_WIDGET (wid->day), 3, 1, 1, 1);
	gtk_widget_set_size_request (wid->day, 90, -1);

	// CLEAR button
	clr_button = gtk_button_new_with_mnemonic ("_Clear");
	gtk_grid_attach (GTK_GRID (grid), clr_button, 0, 2, 2, 1);
	g_signal_connect (clr_button, "clicked", G_CALLBACK (clr_clicked), (gpointer) wid);
	// OKAY button
	ok_button = gtk_button_new_with_mnemonic ("_Okay");
	gtk_grid_attach (GTK_GRID (grid), ok_button, 2, 2, 2, 1);
	g_signal_connect (ok_button, "clicked", G_CALLBACK (ok_clicked), (gpointer) wid);

	gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	struct my_widgets *wid = g_malloc (sizeof (struct my_widgets));

	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer) wid);
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	g_free (wid);
	wid = NULL;
	return status;
}
/*! EOF */
