/*!
 * Simple GTK Greeter Demo Application using Glade/GtkBuilder
 *
 * M. Horauer
 *
 * Build instructions:
 * clang hello_gtk_v5.c `pkg-config --cflags --libs gtk+-3.0` -rdynamic
 *     -o greeter -Wall -g
 */
#include <gtk/gtk.h>
#include <string.h>

struct myWidgets{
	GtkWidget *label_output;
	GtkWidget *input_entry;
};

void
ok_clicked (GtkWidget *widget, gpointer data)
{
	gchar *buffer1, *buffer2;
	struct myWidgets *mw = (struct myWidgets *)data;

	buffer1 = (gchar*) gtk_entry_get_text (GTK_ENTRY (mw->input_entry));
	buffer2 = g_malloc (sizeof (gchar) * (strlen (buffer1) + 7));
	sprintf (buffer2, "Hello %s!", buffer1);
	gtk_label_set_text (GTK_LABEL (mw->label_output), buffer2);
	g_free (buffer2);
}

void
clr_clicked (GtkWidget *widget, gpointer data)
{
	struct myWidgets *mw = (struct myWidgets *)data;
	
	gtk_entry_set_text (GTK_ENTRY (mw->input_entry), "");
	gtk_entry_set_placeholder_text (GTK_ENTRY (mw->input_entry), "e.g., Muster");
	gtk_label_set_text (GTK_LABEL (mw->label_output), "Hello ?");
}

void
destroy_clicked (GtkWidget *widget, gpointer data)
{
	struct myWidgets *mw = (struct myWidgets *)data;

	g_free(mw);
	gtk_main_quit();
}

int
main (int argc, char *argv[])
{
	GtkWidget *window;
	GtkBuilder *builder;

	struct myWidgets *mw = g_malloc(sizeof(struct myWidgets));
	
	gtk_init (&argc, &argv);

	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, "greeter.ui", NULL);

	window = GTK_WIDGET (gtk_builder_get_object (builder, "window"));
	gtk_builder_connect_signals (builder, (gpointer)mw);

	mw->input_entry = GTK_WIDGET (gtk_builder_get_object (builder,
							  "input_entry"));
	mw->label_output = GTK_WIDGET (gtk_builder_get_object (builder,
							   "label_output"));

	g_object_unref (builder);
	gtk_widget_show (window);
	gtk_main();

	return 0;
}
/** EOF */
