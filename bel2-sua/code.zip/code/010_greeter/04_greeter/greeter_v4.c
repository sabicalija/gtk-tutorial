/*!
 * Simple GTK Greeter Demo Application
 */
#include <gtk/gtk.h>
#include <string.h>

// struct that collects all widgets we will use in various callbacks
struct my_widgets {
	GtkWidget *label_output;
	GtkWidget *input_entry;
};

// callback executed when the "Okay" button is clicked, or "Enter" is hit in the
// entry box
static void
ok_clicked (GtkWidget *widget, gpointer data)
{
	gchar *buffer1, *buffer2;
	// obtain references to the widgets passed as generic data pointer
	struct my_widgets *wid = (struct my_widgets*) data;
	// obtain text from the entry box
	buffer1 = (gchar*) gtk_entry_get_text (GTK_ENTRY (wid->input_entry));
	// allocate memory for the final text
	buffer2 = g_malloc (sizeof (gchar) * (strlen (buffer1) + 7));
	// assemble the final text
	sprintf (buffer2, "Hello %s!", buffer1);
	// write the final text to the label on top
	gtk_label_set_text (GTK_LABEL (wid->label_output), buffer2);
	// free the memory
	g_free (buffer2);
}

// callback that is executed when the "Clear" button is clicked
static void
clr_clicked (GtkWidget *widget, gpointer data)
{
	struct my_widgets *wid = (struct my_widgets*) data;
	// clear the entry box
	gtk_entry_set_text (GTK_ENTRY (wid->input_entry), "");
	// put the placeholder text into the entry box
	gtk_entry_set_placeholder_text (GTK_ENTRY (wid->input_entry), "e.g., Muster");
	// clear the label
	gtk_label_set_text (GTK_LABEL (wid->label_output), "Hello ?");
}

static void
apply_css (GtkWidget *widget, GtkStyleProvider *provider)
{
	gtk_style_context_add_provider (gtk_widget_get_style_context (widget),
					provider, G_MAXUINT);
	if (GTK_IS_CONTAINER (widget))
		gtk_container_forall (GTK_CONTAINER (widget), (GtkCallback) apply_css,
				      provider);
}

// app activate callback - creates the window
static void
activate (GtkApplication* app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *grid;
	GtkWidget *label_name;
	GtkWidget *clr_button, *ok_button;
	GtkWidget *headerbar;
	GtkStyleContext *context;
	GtkStyleProvider *provider;
	GtkWidget *box;

	struct my_widgets *wid = (struct my_widgets*) user_data;

	// create the window and associate an icon
	window = gtk_application_window_new (app);
	gtk_window_set_resizable (GTK_WINDOW (window), FALSE);
	gtk_window_set_default_icon_from_file ("icon.png", NULL);
	gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);

	// create a grid to be used as layout container
	grid = gtk_grid_new();
	gtk_grid_set_column_homogeneous (GTK_GRID (grid), FALSE);
	gtk_container_add (GTK_CONTAINER (window), grid);
	gtk_container_set_border_width (GTK_CONTAINER(window), 10);

	// output label using a fancy font from "Google Font Dir"
	// NOTE - the box is only used to make the label more
	//        convenient selectable using the CSS - see below
	box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	wid->label_output = gtk_label_new ("Hello ?");
	// name the label so that we can reference it from the CSS file
	gtk_widget_set_name(wid->label_output, "label_output");
	gtk_box_pack_start (GTK_BOX (box), wid->label_output, TRUE, TRUE, 0);
	gtk_widget_set_size_request (wid->label_output, 400, 50);
	gtk_grid_attach (GTK_GRID (grid), box, 0, 0, 2, 1);

	// name label - label text horizontally aligned at towards the end
	label_name = gtk_label_new ("Name:");
	gtk_widget_set_halign (label_name, GTK_ALIGN_END);
	gtk_widget_set_size_request (label_name, 60, 40);
	gtk_grid_attach (GTK_GRID (grid), label_name, 0, 1, 1, 1);
	// text entry with a placeholder text
	wid->input_entry = gtk_entry_new();
	gtk_grid_attach (GTK_GRID (grid), wid->input_entry, 1, 1, 1, 1);
	gtk_entry_set_placeholder_text (GTK_ENTRY (wid->input_entry), "e.g., Muster");
	// connect a signal when ENTER is hit within the entry box
	g_signal_connect (wid->input_entry, "activate", G_CALLBACK (ok_clicked), (gpointer) wid);

	// create a headerbar
	headerbar = gtk_header_bar_new ();
	gtk_widget_show (headerbar);
	gtk_header_bar_set_title (GTK_HEADER_BAR (headerbar), "GNOME Greeter");
	gtk_header_bar_set_subtitle (GTK_HEADER_BAR (headerbar),
				     "A simple demo application");
	gtk_header_bar_set_show_close_button (GTK_HEADER_BAR (headerbar), TRUE);
	gtk_window_set_titlebar (GTK_WINDOW (window), headerbar);

	// put a red clear button to the left side of the header bar
	clr_button = gtk_button_new_with_mnemonic ("_Clear");
	context = gtk_widget_get_style_context (clr_button);
	gtk_style_context_add_class (context, "text-button");
	gtk_style_context_add_class (context, "destructive-action");
	gtk_header_bar_pack_start (GTK_HEADER_BAR (headerbar), clr_button);
	// connect a signal when the CLEAR button is clicked
	g_signal_connect (clr_button, "clicked", G_CALLBACK (clr_clicked), (gpointer) wid);

	// put a blue okay button to the left side of the header bar
	ok_button = gtk_button_new_with_mnemonic ("_Okay");
	context = gtk_widget_get_style_context (ok_button);
	gtk_style_context_add_class (context, "text-button");
	gtk_style_context_add_class (context, "suggested-action");
	gtk_header_bar_pack_end (GTK_HEADER_BAR (headerbar), ok_button);
	// connect a signal when the OKAY button is clicked
	g_signal_connect (ok_button, "clicked", G_CALLBACK (ok_clicked), (gpointer) wid);

	// add a fancy background image
	provider = GTK_STYLE_PROVIDER (gtk_css_provider_new ());
	gtk_css_provider_load_from_resource (GTK_CSS_PROVIDER (provider), "/css_greeter/css_greeter.css");
	apply_css (window, provider);
	// end of background image

	gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	// we need some memory for the widgets struct
	struct my_widgets *wid = g_malloc (sizeof (struct my_widgets));

	// create a threaded application
	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer) wid);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	// free the memory for the widgets struct
	g_free (wid);
	wid = NULL;

	return status;
}
/** EOF */
