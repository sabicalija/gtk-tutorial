/**
 * Callbacks for Classic GTK+ Menu Demo using a GtkApplication class
 *
 * M. Horauer
 */

#ifndef _menucallbacks_
#define _menucallbacks_

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

/***************************************************************** PROTOTYPES */
void message_dialog (GSimpleAction *action, GVariant *parameter, gpointer data);
void quit_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void open_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void save_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void saveAs_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void add_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void del_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void find_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void about_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
void help_callback (GSimpleAction *action, GVariant *parameter, gpointer data);

#endif
