/*!
 * Simple INFOBAR Demo Application
 *
 * Version 1
 * M. Horauer
 *
 * Build instructions:
 * gcc infobar.c `pkg-config --cflags --libs gtk+-3.0` -o infobar -Wall -g
 */
#include <gtk/gtk.h>
#include <string.h>

// struct that collects all widgets we will use in various callbacks
struct my_widgets {
	GtkApplication *app;
	GtkWidget *window;
	GtkWidget *input_entry;
	GtkWidget *grid;
};

// callback executed when ENTER is pressed within the entry box
static void
on_bar_response (GtkInfoBar *info_bar, gint response_id, gpointer data)
{
	// obtain references to the widgets passed as generic data pointer
	struct my_widgets *wid = (struct my_widgets*) data;

	// the user clicks the X button in the INFOBAR -> hide the INFOBAR
	if (response_id == GTK_RESPONSE_CLOSE) {
		gtk_widget_hide (GTK_WIDGET (info_bar));
		return;
	}
	// the user clicks the QUIT button in the INFOBAR -> terminate
	if (response_id == GTK_RESPONSE_OK) {
		g_application_quit (G_APPLICATION (wid->app));
	}
}

// callback executed when the "Okay" button is clicked, or "Enter" is hit in the
// entry box
static void
eval_answer (GtkWidget *widget, gpointer data)
{
	gchar *buffer1;
	GtkWidget *label;
	GtkWidget *image;
	static GtkWidget *bar = NULL;

	// obtain references to the widgets passed as generic data pointer
	struct my_widgets *wid = (struct my_widgets*) data;
	// obtain text from the entry box
	buffer1 = (gchar*) gtk_entry_get_text (GTK_ENTRY (wid->input_entry));

	// in case an INFOBAR is shown - hide it
	if (bar != NULL)
		gtk_widget_hide (GTK_WIDGET (bar));
	// when 42 + ENTER is given - show an INFOBAR with a QUIT button
	if (g_ascii_strcasecmp (buffer1, "42") == 0) {
		// we create an INFOBAR with a button
		bar = gtk_info_bar_new_with_buttons ("Quit", GTK_RESPONSE_OK, NULL);
		gtk_grid_attach (GTK_GRID (wid->grid), bar, 0, 0, 1, 1);
		gtk_info_bar_set_message_type (GTK_INFO_BAR (bar), GTK_MESSAGE_INFO);
		// we add a symbolic icon to the INFOBAR
		image = gtk_image_new_from_icon_name ("face-cool", GTK_ICON_SIZE_DIALOG);
		gtk_box_pack_start (GTK_BOX (gtk_info_bar_get_content_area (GTK_INFO_BAR (bar))), 
		                    image, FALSE, FALSE, 0);
		// we add a label to the INFOBAR
		label = gtk_label_new ("Correct! Cute :-)");
		gtk_label_set_line_wrap (GTK_LABEL (label), TRUE);
		gtk_label_set_xalign (GTK_LABEL (label), 0);
		gtk_box_pack_start (GTK_BOX (gtk_info_bar_get_content_area (GTK_INFO_BAR (bar))), 
		                    label, FALSE, FALSE, 0);
		g_signal_connect (bar, "response", G_CALLBACK (on_bar_response), 
		                  (gpointer) wid);
	} else {
		// we create an INFOBAR
		bar = gtk_info_bar_new ();
		gtk_grid_attach (GTK_GRID (wid->grid), bar, 0, 0, 1, 1);
		gtk_info_bar_set_message_type (GTK_INFO_BAR (bar), GTK_MESSAGE_ERROR);
		// we add a symbolic icon image to the INFOBAR
		image = gtk_image_new_from_icon_name ("face-sad", GTK_ICON_SIZE_DIALOG);
		gtk_box_pack_start (GTK_BOX (gtk_info_bar_get_content_area (GTK_INFO_BAR (bar))), 
		                    image, FALSE, FALSE, 0);
		// we add a label to the INFOBAR
		label = gtk_label_new ("Lol, go sit in a corner!");
		gtk_label_set_line_wrap (GTK_LABEL (label), TRUE);
		gtk_label_set_xalign (GTK_LABEL (label), 0);
		gtk_box_pack_start (GTK_BOX (gtk_info_bar_get_content_area (GTK_INFO_BAR (bar))), 
		                    label, FALSE, FALSE, 0);
		// we add a CLOSE button to the INFOBAR
		gtk_info_bar_set_show_close_button (GTK_INFO_BAR (bar), TRUE);
		gtk_widget_grab_focus (bar);
		// connect a signal to the CLOSE button
		g_signal_connect (bar, "response", G_CALLBACK (on_bar_response), 
		                  (gpointer) wid);
	}
	gtk_widget_show_all (bar);
}

// app activate callback - creates the window
static void
activate (GtkApplication* app, gpointer user_data)
{

	GtkWidget *label;
	struct my_widgets *wid = (struct my_widgets*) user_data;

	// create the window and set a title
	wid->window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (wid->window), "Infobar Demo");
	gtk_window_set_default_icon_from_file ("icon.png", NULL);
	gtk_window_set_resizable (GTK_WINDOW (wid->window), FALSE);

	// create a grid to be used as layout container
	wid->grid = gtk_grid_new();
	gtk_container_add (GTK_CONTAINER (wid->window), wid->grid);
	gtk_container_set_border_width (GTK_CONTAINER (wid->window), 10);

	label = gtk_label_new ("What's the answer?");
	gtk_grid_attach (GTK_GRID (wid->grid), label, 0, 1, 1, 1);

	// text entry box
	wid->input_entry = gtk_entry_new();
	gtk_grid_attach (GTK_GRID (wid->grid), wid->input_entry, 0, 2, 1, 1);
	// right align the cursor in the entry box
	gtk_entry_set_alignment (GTK_ENTRY (wid->input_entry), 1);
	// connect a signal when ENTER is hit -> invoke ok_clicked() callback
	//   and passes a generic pointer to the struct containing references to some
	//   widgets
	g_signal_connect (wid->input_entry, "activate", G_CALLBACK (eval_answer),
			  (gpointer) wid);

	gtk_widget_show_all (wid->window);
}

int
main (int argc, char **argv)
{
	int status;
	// we need some memory for the widgets struct
	struct my_widgets *wid = g_malloc (sizeof (struct my_widgets));

	// create a threaded application
	wid->app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (wid->app, "activate", G_CALLBACK (activate), (gpointer) wid);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (wid->app), argc, argv);
	g_object_unref (wid->app);

	// free the memory for the widgets struct
	g_free (wid);
	wid = NULL;
	return status;
}
/** EOF */
