/*!
 * Simple Statusbar Demo Program
 *
 * Illustrates the use of a status bar along with a colored text label and 
 * styled buttons.
 *
 * M. Horauer
 *
 */
#include <gtk/gtk.h>

struct myWidgets {
	GtkWidget *statusbar;
	guint id;
};

static void
push_clicked (GtkWidget * widget, gpointer data)
{
	struct myWidgets * w = (struct myWidgets *) data;
	gchar * msg = g_malloc (256);
	static gint cnt = 0;

	g_snprintf (msg, 256, "Message number %d", cnt++);
	gtk_statusbar_push (GTK_STATUSBAR (w->statusbar), w->id, msg);
}

static void
pop_clicked (GtkWidget * widget, gpointer data)
{
	struct myWidgets * w = (struct myWidgets *) data;

	gtk_statusbar_pop (GTK_STATUSBAR (w->statusbar), w->id);
}

static void
remove_clicked (GtkWidget * widget, gpointer data)
{
	struct myWidgets * w = (struct myWidgets *) data;

	gtk_statusbar_remove_all (GTK_STATUSBAR (w->statusbar), w->id);
}

int main (int argc, char *argv[])
{
	GtkWidget *window, *box, *hbox, *label;
	GtkWidget *pushbutton, *popbutton, *removebutton;
	GtkStyleContext *context;
	GtkCssProvider *provider;
	GdkDisplay *display;
	GdkScreen *screen;

	gtk_init (&argc, &argv);

	struct myWidgets *w = g_malloc (sizeof (struct myWidgets));

	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request (window, 300, 150);
	gtk_window_set_default_icon_from_file ("icon.png", NULL);
	gtk_window_set_resizable (GTK_WINDOW (window), FALSE);
	g_signal_connect (G_OBJECT (window), "destroy",
			  G_CALLBACK (gtk_main_quit), NULL);

	box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add (GTK_CONTAINER (window), box);
	/* Label with opacity set */
	label = gtk_label_new ("Statusbar Demo");
	gtk_box_pack_start (GTK_BOX (box), label, TRUE, TRUE, 0);
	gtk_widget_set_opacity (label, 0.8);

	/* Box Layout container for the buttons */
	hbox = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start (GTK_BOX (box), hbox, FALSE, FALSE, 0);

	/* PUSH button -> styled */
	pushbutton = gtk_button_new_with_label ("Push");
	gtk_box_pack_start (GTK_BOX (hbox), pushbutton, TRUE, FALSE, 0);
	gtk_widget_set_size_request (pushbutton, 100, 15);
	g_signal_connect (G_OBJECT (pushbutton), "clicked",
			  G_CALLBACK (push_clicked), (gpointer) w);
	context = gtk_widget_get_style_context (pushbutton);
	gtk_style_context_add_class (context, "suggested-action");

	/* POP button */
	popbutton = gtk_button_new_with_label ("Pop");
	gtk_box_pack_start (GTK_BOX (hbox), popbutton, TRUE, FALSE, 0);
	gtk_widget_set_size_request (popbutton, 100, 15);
	g_signal_connect (G_OBJECT (popbutton), "clicked",
			  G_CALLBACK (pop_clicked), (gpointer) w);

	/* REMOVE button -> styled */
	removebutton = gtk_button_new_with_label ("Remove");
	gtk_box_pack_start (GTK_BOX (hbox), removebutton, TRUE, FALSE, 0);
	gtk_widget_set_size_request (removebutton, 100, 15);
	g_signal_connect (G_OBJECT (removebutton), "clicked",
			  G_CALLBACK (remove_clicked), (gpointer) w);
	context = gtk_widget_get_style_context (removebutton);
	gtk_style_context_add_class (context, "destructive-action");

	/* Statusbar */
	w->statusbar = gtk_statusbar_new();
	gtk_widget_set_size_request (w->statusbar, 300, 10);
	gtk_box_pack_start (GTK_BOX (box), w->statusbar, FALSE, FALSE, 0);
	w->id = gtk_statusbar_get_context_id (GTK_STATUSBAR (w->statusbar), "demo");
	context = gtk_widget_get_style_context (w->statusbar);

	/* style the statusbar text using a color */
	provider = gtk_css_provider_new ();
	display = gdk_display_get_default ();
	screen = gdk_display_get_default_screen (display);
	gtk_style_context_add_provider_for_screen (screen,
						   GTK_STYLE_PROVIDER (provider),
						   GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
	gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (provider),
					 " GtkStatusbar {\n"
					 "   color: green;\n"
					 "}\n", -1, NULL);
	g_object_unref (provider);
	/* */

	gtk_widget_show_all (window);
	gtk_main();

	g_free (w);
	return 0;
}
/** EOF */
