#include <gtk/gtk.h>

typedef struct _ProgressData {
	GtkWidget *progressbar;
	int timer;
	gboolean show_text;
	gboolean activity_mode;
} ProgressData;

static gboolean 
pb_progress_timeout (gpointer data)
{
	gdouble val;
	ProgressData *pb = (ProgressData *) data;

	if (pb->activity_mode)
	{
		// display an activity bar
		gtk_progress_bar_pulse (GTK_PROGRESS_BAR (pb->progressbar));
	}
	else {
		// increment the progress bar
		val = gtk_progress_bar_get_fraction (GTK_PROGRESS_BAR (pb->progressbar)) + 0.1;
		if (val > 1.0)
			val = 0.0;
		gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (pb->progressbar), val);
	}
	// as long as it returns TRUE the timeout keeps running
	return TRUE;
}

static void
pb_toggle_show_text (GtkWidget *widget, gpointer data)
{
	ProgressData *pb = (ProgressData *) data;

	if (pb->show_text) {
		// remove the text on top of the progressbar
		pb->show_text = FALSE;
		gtk_progress_bar_set_show_text (GTK_PROGRESS_BAR (pb->progressbar), FALSE);
	} else {
		// show the text of the progressbar
		pb->show_text = TRUE;
		gtk_progress_bar_set_show_text (GTK_PROGRESS_BAR (pb->progressbar), TRUE);
		gtk_progress_bar_set_text (GTK_PROGRESS_BAR (pb->progressbar), NULL);
	}
}

static void
pb_toggle_activity_mode (GtkWidget *widget,  gpointer data)
{
	ProgressData *pb = (ProgressData *) data;

	// toggle the activity mode
	pb->activity_mode = !pb->activity_mode;

	if (pb->activity_mode)
		// start the acivity bar on the left side
		gtk_progress_bar_pulse (GTK_PROGRESS_BAR (pb->progressbar));
	else
		// start the progress bar on the left side
		gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (pb->progressbar), 0.0);
}

// app activate callback - creates the window
static void
pb_activate (GtkApplication *app, gpointer data)
{
	ProgressData *pb;
	GtkWidget *window;
	GtkWidget *vbox;
	GtkWidget *checkbutton;

	pb = (ProgressData *) data;
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_application (GTK_WINDOW (window), GTK_APPLICATION (app));
	gtk_window_set_title (GTK_WINDOW (window), "ProgressBar Demo");
	gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
	gtk_window_set_default_size (GTK_WINDOW (window), 300, 80);
	gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);

	vbox = gtk_box_new (GTK_ORIENTATION_VERTICAL, 5);
	gtk_container_add (GTK_CONTAINER (window), vbox);

	// show either progressbar (initially) or activitybar
	pb->activity_mode = FALSE;
	// initially hide the text on the progressbar
	pb->show_text = FALSE;
	// create a progressbar
	pb->progressbar = gtk_progress_bar_new();
	gtk_box_pack_start (GTK_BOX (vbox), pb->progressbar, TRUE, FALSE, 0);
	// create two checkbuttons
	checkbutton = gtk_check_button_new_with_label ("Display text");
	g_signal_connect (checkbutton, "clicked", G_CALLBACK (pb_toggle_show_text),
			  (gpointer) pb);
	gtk_box_pack_start (GTK_BOX (vbox), checkbutton, TRUE, FALSE, 0);
	checkbutton = gtk_check_button_new_with_label ("Activity mode");
	g_signal_connect (checkbutton, "clicked", G_CALLBACK (pb_toggle_activity_mode),
			  (gpointer) pb);
	gtk_box_pack_start (GTK_BOX (vbox), checkbutton, TRUE, FALSE, 0);

	// setup a timeout - when the timeout expires invoke a callback
	pb->timer = g_timeout_add (1000, pb_progress_timeout, (gpointer) pb);

	gtk_widget_show_all (GTK_WIDGET (window));
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	ProgressData *pb = g_malloc (sizeof (ProgressData));

	app = gtk_application_new ("org.gtk.progressbar", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (pb_activate), (gpointer) pb);
	status = g_application_run (G_APPLICATION (app), argc, argv);
	// remove the timer
	g_source_remove (pb->timer);
	pb->timer = 0;
	g_object_unref (app);
	g_free (pb);
	return status;
}
/** EOF */


