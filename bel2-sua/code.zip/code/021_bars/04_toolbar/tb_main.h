#ifndef _tb_main_
#define _tb_main_

#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

struct tbWidgets {
	GtkWidget *gridlabel;
	GtkWidget *drawlabel;
	GtkWidget *draw_rect_button;
	GtkWidget *draw_line_button;
};

#include "tb_toolbar.h"

#endif
