#include "tb_toolbar.h"

void
tb_grid_button_cb (GtkWidget *widget, gpointer data)
{
	gboolean state;
	GtkWidget *img;
	struct tbWidgets *mw = (struct tbWidgets *) data;

	state = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget));
	if (state == FALSE) {
		g_message ("Grid Off");
		img = gtk_image_new_from_file ("icons/grid_off.png");
		gtk_button_set_image (GTK_BUTTON (widget), img);
		gtk_label_set_text (GTK_LABEL (mw->gridlabel), "Grid Off");
	} else {
		g_message ("Grid On");
		img = gtk_image_new_from_file ("icons/grid_on.png");
		gtk_button_set_image (GTK_BUTTON (widget), img);
		gtk_label_set_text (GTK_LABEL (mw->gridlabel), "Grid On");
	}
}

void
tb_draw_line_cb (GtkWidget *widget, gpointer data)
{
	gboolean state;
	struct tbWidgets *mw = (struct tbWidgets *) data;


	state = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget));
	if (state == FALSE) {
		g_message ("Draw Off");
		gtk_label_set_text (GTK_LABEL (mw->drawlabel), "Draw Off");
	} else {
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (mw->draw_rect_button), FALSE);
		g_message ("Draw Line");
		gtk_label_set_text (GTK_LABEL (mw->drawlabel), "Draw Line");
	}
}

void
tb_draw_rect_cb (GtkWidget *widget, gpointer data)
{
	gboolean state;
	struct tbWidgets *mw = (struct tbWidgets *) data;


	state = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget));
	if (state == FALSE) {
		g_message ("Draw Off");
		gtk_label_set_text (GTK_LABEL (mw->drawlabel), "Draw Off");
	} else {
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (mw->draw_line_button), FALSE);
		g_message ("Draw Rect");
		gtk_label_set_text (GTK_LABEL (mw->drawlabel), "Draw Rect");
	}
}

void
tb_construct_toolbar (GtkWidget *frame, struct tbWidgets *mw)
{
	GtkWidget *toolbar_box;
	GtkWidget *grid_button;
	GtkWidget *grid_img, *line_img, *rect_img;

	// TOOLBAR
	toolbar_box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add (GTK_CONTAINER (frame), toolbar_box);
	g_object_set (toolbar_box, "margin", 0, NULL);
	gtk_style_context_add_class (gtk_widget_get_style_context (toolbar_box),
				     GTK_STYLE_CLASS_LINKED);

	// GRID toolbar button
	grid_button = gtk_toggle_button_new ();
	grid_img = gtk_image_new_from_file ("icons/grid_off.png");
	gtk_button_set_image (GTK_BUTTON (grid_button), grid_img);
	gtk_widget_set_tooltip_text (grid_button, "Toggles the grid on/off");
	gtk_container_add (GTK_CONTAINER (toolbar_box), grid_button);
	g_signal_connect (G_OBJECT (grid_button), "toggled",
			  G_CALLBACK (tb_grid_button_cb), (gpointer) mw);

	// DRAW LINE button
	mw->draw_line_button = gtk_toggle_button_new ();
	line_img = gtk_image_new_from_file ("icons/draw_line.png");
	gtk_button_set_image (GTK_BUTTON (mw->draw_line_button), line_img);
	gtk_widget_set_tooltip_text (mw->draw_line_button, "Draw a line");
	gtk_container_add (GTK_CONTAINER (toolbar_box), mw->draw_line_button);
	g_signal_connect (G_OBJECT (mw->draw_line_button), "toggled",
			  G_CALLBACK (tb_draw_line_cb), (gpointer) mw);
	// DRAW RECTANGLE button
	mw->draw_rect_button = gtk_toggle_button_new ();
	rect_img = gtk_image_new_from_file ("icons/draw_rect.png");
	gtk_button_set_image (GTK_BUTTON (mw->draw_rect_button), rect_img);
	gtk_widget_set_tooltip_text (mw->draw_rect_button, "Draw a rectangle");
	gtk_container_add (GTK_CONTAINER (toolbar_box), mw->draw_rect_button);
	g_signal_connect (G_OBJECT (mw->draw_rect_button), "toggled",
			  G_CALLBACK (tb_draw_rect_cb), (gpointer) mw);
}
