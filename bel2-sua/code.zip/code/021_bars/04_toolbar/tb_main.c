#include "tb_main.h"

// app activate callback - creates the window
static void
tb_activate (GtkApplication *app, gpointer data)
{
	GtkWidget *window;
	GtkWidget *box;
	GtkWidget *labelbox;
	GtkWidget *frame;

	struct tbWidgets *mw = (struct tbWidgets *) data;

	// create a top level window and set some properties
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_application (GTK_WINDOW (window), GTK_APPLICATION (app));
	gtk_window_set_title (GTK_WINDOW (window), "Simple Toolbar Demo");
	gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
	gtk_window_set_default_icon_from_file ("icons/icon.png", NULL);
	gtk_window_set_default_size (GTK_WINDOW (window), 200, 200);
	gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);

	box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_container_add (GTK_CONTAINER (window), box);

	frame = gtk_frame_new (NULL);
	gtk_frame_set_shadow_type (GTK_FRAME (frame), GTK_SHADOW_IN);
	gtk_box_pack_start (GTK_BOX (box), frame, FALSE, FALSE, 0);

	// CONSTRUCT a TOOLBAR
	tb_construct_toolbar (frame, mw);

	labelbox = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start (GTK_BOX (box), labelbox, TRUE, TRUE, 0);

	mw->gridlabel = gtk_label_new ("Grid Off");
	gtk_box_pack_start (GTK_BOX (labelbox), mw->gridlabel, TRUE, TRUE, 0);
	mw->drawlabel = gtk_label_new ("No Draw selected");
	gtk_box_pack_start (GTK_BOX (labelbox), mw->drawlabel, TRUE, TRUE, 0);

	// show all widgets
	gtk_widget_show_all (GTK_WIDGET (window));
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	// we need some memory for the widgets struct
	struct tbWidgets *mw = g_malloc (sizeof (struct tbWidgets));

	// create a threaded application
	app = gtk_application_new ("org.gtk.toolbar", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (tb_activate), (gpointer) mw);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);
	// free the memory for the widgets struct
	g_free (mw);
	return status;
}
/** EOF */
