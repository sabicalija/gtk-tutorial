#ifndef _tb_toolbar_
#define _tb_toolbar_

#include "tb_main.h"

void
tb_construct_toolbar (GtkWidget *frame, struct tbWidgets *mw);

#endif
