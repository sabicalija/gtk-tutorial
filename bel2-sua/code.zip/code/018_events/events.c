/*!
 * Simple Event Demo Application
 *
 * Illustrates various mouse events - left-, middle-, right-click, scroll-up,
 * and scroll-down using an event box. Upon events, the images are changed.
 *
 * M. Horauer
 *
 */
#include <gtk/gtk.h>

struct myWin {
	GtkWidget *img;
	GtkWidget *label;
};

static void eventButtonHandler (GtkWidget *widget, GdkEvent *event, gpointer data);
static void eventScrollWheelHandler (GtkWidget *widget, GdkEvent *event, gpointer data);
static void eventKeyHandler (GtkWidget *widget, GdkEvent *event, gpointer data);

static void
eventButtonHandler (GtkWidget *widget, GdkEvent *event, gpointer data)
{
	static guint eventSource = 0;
	struct myWin *mw = (struct myWin *) data;
	guint *value = g_malloc (sizeof (guint));

	// handle mouse button events
	gdk_event_get_button (event, value);
	// left mouse button
	if (*value == GDK_BUTTON_PRIMARY) {
		if (eventSource == 0 || eventSource == 2 || eventSource == 3) {
			gtk_image_set_from_file (GTK_IMAGE (mw->img), "t1.png");
			eventSource = 1;
			return;
		}
		if (eventSource == 1) {
			gtk_image_set_from_file (GTK_IMAGE (mw->img), "deck.png");
			eventSource = 0;
			return;
		}
	}
	// middle mouse button
	if (*value == GDK_BUTTON_MIDDLE) {
		if (eventSource == 0 || eventSource == 1 || eventSource == 3) {
			gtk_image_set_from_file (GTK_IMAGE (mw->img), "t2.png");
			eventSource = 2;
			return;
		}
		if (eventSource == 2) {
			gtk_image_set_from_file (GTK_IMAGE (mw->img), "deck.png");
			eventSource = 0;
			return;
		}
	}
	// right mouse button
	if (*value == GDK_BUTTON_SECONDARY) {
		if (eventSource == 0 || eventSource == 1 || eventSource == 2) {
			gtk_image_set_from_file (GTK_IMAGE (mw->img), "t3.png");
			eventSource = 3;
			return;
		}
		if (eventSource == 3) {
			gtk_image_set_from_file (GTK_IMAGE (mw->img), "deck.png");
			eventSource = 0;
			return;
		}
	}
	g_free (value);
}

static void
eventScrollWheelHandler (GtkWidget *widget, GdkEvent *event, gpointer data)
{
	struct myWin *mw = (struct myWin *) data;
	GdkScrollDirection *direction = g_malloc (sizeof (GdkScrollDirection));

	// handle scroll up/down events
	gdk_event_get_scroll_direction (event, direction);
	if (*direction == GDK_SCROLL_UP)
		gtk_image_set_from_file (GTK_IMAGE (mw->img), "t4.png");
	if (*direction == GDK_SCROLL_DOWN)
		gtk_image_set_from_file (GTK_IMAGE (mw->img), "t5.png");
	g_free (direction);
}

static void
eventKeyHandler (GtkWidget *widget, GdkEvent *event, gpointer data)
{
	struct myWin *mw = (struct myWin *) data;
	guint *keyval = g_malloc (sizeof (guint));

	// handle key events - checkout gtk-3.0/gdk/gdkkeysyms.h
	gdk_event_get_keyval (event, keyval);
	if (*keyval == GDK_KEY_space)
		gtk_label_set_text(GTK_LABEL(mw->label), "SPACE");
	if (*keyval == GDK_KEY_a)
		gtk_label_set_text(GTK_LABEL(mw->label), "a");
	if (*keyval == GDK_KEY_A)
		gtk_label_set_text(GTK_LABEL(mw->label), "A");
	if (*keyval == GDK_KEY_Escape)
		gtk_label_set_text(GTK_LABEL(mw->label), "ESC");
	if (*keyval == GDK_KEY_Shift_L)
		gtk_label_set_text(GTK_LABEL(mw->label), "SHIFT LEFT");
	g_free (keyval);
}


// app activate callback - creates the window
static void
activate (GtkApplication *app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *box;
	GtkWidget *event;
	struct myWin *mw = (struct myWin *) user_data;

	// create a top level window and set some properties
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_application (GTK_WINDOW (window), GTK_APPLICATION (app));
	gtk_window_set_title (GTK_WINDOW (window), "Event Demo");
	gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
	gtk_window_set_default_icon_from_file ("icon.png", NULL);
	gtk_window_set_default_size (GTK_WINDOW (window), 200, 50);
	gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);

	// we use a box container - not neccessary here
	box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add (GTK_CONTAINER (window), box);
	// create an event box and add it to the layout container box
	event = gtk_event_box_new();
	gtk_box_pack_start (GTK_BOX (box), event, TRUE, TRUE, 5);
	gtk_widget_set_tooltip_text(event, "Click a mouse button or\nscroll the mouse wheel.");
	// add an image into the event box
	mw->img = gtk_image_new_from_file ("deck.png");
	gtk_container_add (GTK_CONTAINER (event), mw->img);
	// we add a label below
	mw->label = gtk_label_new("Show Mouse/Key Events");
	gtk_box_pack_start (GTK_BOX (box), mw->label, FALSE, FALSE, 5);
	gtk_widget_set_tooltip_text(mw->label, "Press: ESC, SPACE, a, A or SHIFT LEFT");

	// we add signals for mouse button clicks and mouse scroll-wheel events
	g_signal_connect (event, "button-press-event", G_CALLBACK (eventButtonHandler),
			  (gpointer) mw);
	// see http://stackoverflow.com/questions/10355779/how-to-catch-gtk-scroll-event-on-menu-item
	gtk_widget_add_events (GTK_WIDGET (event), GDK_SCROLL_MASK);
	g_signal_connect (event, "scroll-event", G_CALLBACK (eventScrollWheelHandler),
			  (gpointer) mw);
	g_signal_connect (window, "key-press-event", G_CALLBACK (eventKeyHandler),
			  (gpointer) mw);

	gtk_widget_show_all (GTK_WIDGET (window));
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	// we need some memory for the widgets struct
	struct myWin *mw = g_malloc (sizeof (struct myWin));

	// create a threaded application
	app = gtk_application_new ("org.gtk.events", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer) mw);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);
	// free the memory for the widgets struct
	g_free (mw);
	return status;
}
/** EOF */
