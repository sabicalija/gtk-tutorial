/*!
 * \brief This file contains a producer, a consumer, and a viewer thread
 *        along with functions that are periodically invoked. The timeout
 *        periods are defined in the header file.
 *
 * \author M. Horauer, 2015
 */

#include "pc_datagen.h"

// local function prototypes
static gboolean produce (gpointer data);
static gboolean consume (gpointer data);
static gboolean view (gpointer data);

// global arrays to store the values
gdouble valuea[NUM];
gdouble valueb[NUM];

/*!
 * \brief viewer thread periodically displays data after a short timeout
 */
gpointer
viewerThread (gpointer data)
{
	appWidgets *w = (appWidgets*) data;

	g_timeout_add (VIEW_PERIOD, (GSourceFunc) view, w);
	return NULL;
}

/*!
 * \brief producer thread periodically produces data after a short timeout
 */
gpointer
producerThread (gpointer data)
{
	g_timeout_add (PRODUCE_PERIOD, (GSourceFunc) produce, NULL);
	return NULL;
}

/*!
 * \brief consumer thread periodically consumes data after short timeout
 */
gpointer
consumerThread (gpointer data)
{
	g_timeout_add (CONSUME_PERIOD, (GSourceFunc) consume, NULL);
	return NULL;
}

/*!
 * \brief generates some data
 */
static gboolean produce (gpointer data)
{
	static gint j = 0;

	G_LOCK (value);
	if (j == NUM)
		j = 0;
	valuea[j] = g_random_double() * 3.3;
	valueb[j] = (gdouble) (sin ( (j * M_PI) / 180)) * 3.3;
	j++;
	G_UNLOCK (value);
	return TRUE;
}

/*!
 * \brief consumes data
 */
static gboolean consume (gpointer data)
{
	G_LOCK (value);
	for (int i = 0; i < NUM; i++) {
		if (valuea[i] >= 0)
			valuea[i] = -1.0;
		if (valueb[i] >= 0)
			valueb[i] = -1.0;
	}
	G_UNLOCK (value);
	return TRUE;
}

/*!
 * \brief view data
 */
static gboolean view (gpointer data)
{
	gboolean state;
	gchar *buffer = g_malloc (60);
	appWidgets *w = (appWidgets*) data;

	state = gtk_switch_get_state (GTK_SWITCH (w->onOff));
	if (state == TRUE) {
		for (int i = 0; i < NUM; i++) {
			G_LOCK (value);
			if (valuea[i] >= 0)
				g_sprintf (buffer, "<span color=\"#AA0000\">%+1.2lf</span>", valuea[i]);
			else
				g_sprintf (buffer, "%+1.2lf", valuea[i]);
			gtk_label_set_text (GTK_LABEL (w->labela[i]), buffer);
			gtk_label_set_use_markup (GTK_LABEL (w->labela[i]), TRUE);

			if (valueb[i] >= 0)
				g_sprintf (buffer, "<span color=\"#0000AA\">%+1.2lf</span>", valueb[i]);
			else
				g_sprintf (buffer, "%+1.2lf", valueb[i]);
			gtk_label_set_text (GTK_LABEL (w->labelb[i]), buffer);
			gtk_label_set_use_markup (GTK_LABEL (w->labelb[i]), TRUE);
			G_UNLOCK (value);
		}
		g_free (buffer);
	}
	return TRUE;
}
/*! EOF */
