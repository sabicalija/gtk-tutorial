#ifndef _pc_datagen_
#define _pc_datagen_

#include <gtk/gtk.h>
#include <glib/gprintf.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

gpointer producerThread (gpointer data);
gpointer consumerThread (gpointer data);
gpointer viewerThread (gpointer data);

/* create a mutex */
G_LOCK_DEFINE (value);

#define NUM 10
#define VIEW_PERIOD 23
#define PRODUCE_PERIOD 77
#define CONSUME_PERIOD 200

typedef struct {
	GtkApplication *app;
	GtkWidget *window;
	GtkWidget *labela[10];
	GtkWidget *labelb[10];
	GtkWidget *onOff;
} appWidgets;

extern gdouble valuea[NUM];
extern gdouble valueb[NUM];

#endif
