/*!
 * \mainpage A demo example showcasing the use of three threads - a producer,
 *           a consumer, and a viewer.
 * \brief This file mainly constructs the GUI - a fixed GtkApplication with
 *        a headerbar containing an on/off switch to enable/disable the update of
 *        the display. The main window consists of a number of labels where
 *        the global arrays are displayed. Non-empty array elements are shown
 *        using colors in order to make them better distinguishable.
 *
 * \author M. Horauer, 2015
 */
#include "pc_datagen.h"

/*!
 * \brief The callback for the on/off switch in the headerbar. The callback
 *        toggles both the state as well as the visibility of the switch.
 */
void switch_callback (GSimpleAction *action, GVariant *parameter, gpointer data)
{
	gboolean state;
	appWidgets *w = (appWidgets*) data;

	state = gtk_switch_get_state (GTK_SWITCH (w->onOff));
	if (state == FALSE) {
		gtk_switch_set_active (GTK_SWITCH (w->onOff), TRUE);
		gtk_switch_set_state (GTK_SWITCH (w->onOff), TRUE);
	} else {
		gtk_switch_set_active (GTK_SWITCH (w->onOff), FALSE);
		gtk_switch_set_state (GTK_SWITCH (w->onOff), FALSE);
	}
}

/*!
 * \brief The following callback constructs the GUI.
 */
static void
activate (GtkApplication *app, gpointer data)
{
	GtkWidget *grid;
	GtkWidget *label;
	GtkWidget *headerbar;
	const GActionEntry app_actions[] = {
		{ "enter", switch_callback, NULL, NULL, NULL }
	};

	appWidgets *w = (appWidgets*) data;

	// create the top-level window
	w->window = gtk_application_window_new (w->app);
	gtk_window_set_application (GTK_WINDOW (w->window), GTK_APPLICATION (w->app));
	gtk_container_set_border_width (GTK_CONTAINER (w->window), 4);
	gtk_window_set_default_icon_from_file ("icon.png", NULL);
	gtk_window_set_resizable (GTK_WINDOW (w->window), FALSE);
	gtk_window_set_title (GTK_WINDOW (w->window), "Producer/Consumer Demo");

	headerbar = gtk_header_bar_new ();
	gtk_widget_show (headerbar);
	gtk_header_bar_set_title (GTK_HEADER_BAR (headerbar), "Producer/Consumer");
	gtk_header_bar_set_subtitle (GTK_HEADER_BAR (headerbar),
				     "Threaded Producer/Consumer Demo");
	gtk_header_bar_set_show_close_button (GTK_HEADER_BAR (headerbar), TRUE);
	gtk_window_set_titlebar (GTK_WINDOW (w->window), headerbar);
	// we add the labels and a switch in the headerbar
	grid = gtk_grid_new();
	gtk_container_add (GTK_CONTAINER (w->window), grid);
	// make some space between the labels
	gtk_grid_set_column_spacing (GTK_GRID (grid), 4);
	gtk_grid_set_row_spacing (GTK_GRID (grid), 4);
	// create all the labels and place them into the grid
	for (int i = 0; i < NUM; i++) {
		gchar *buf = g_malloc (20);

		g_sprintf (buf, "ValueA[%d]:", i);
		label = gtk_label_new (buf);
		gtk_grid_attach (GTK_GRID (grid), label, 0, i, 1, 1);
		// right align
		gtk_label_set_xalign (GTK_LABEL (label), 1.0);
		// request a minimum size
		gtk_widget_set_size_request (label, 100, 25);

		w->labela[i] = gtk_label_new ("-1.00");
		gtk_label_set_xalign (GTK_LABEL (w->labela[i]), 1.0);
		gtk_grid_attach (GTK_GRID (grid), w->labela[i], 1, i, 1, 1);
		// center align
		gtk_label_set_xalign (GTK_LABEL (w->labela[i]), 0.5);
		// request a minimum size
		gtk_widget_set_size_request (w->labela[i], 100, 25);

		g_sprintf (buf, "ValueB[%d]:", i);
		label = gtk_label_new (buf);
		gtk_grid_attach (GTK_GRID (grid), label, 2, i, 1, 1);
		// right align
		gtk_label_set_xalign (GTK_LABEL (label), 1.0);
		// request minimum size
		gtk_widget_set_size_request (label, 100, 25);

		w->labelb[i] = gtk_label_new ("-1.00");
		gtk_label_set_xalign (GTK_LABEL (w->labelb[i]), 1.0);
		gtk_grid_attach (GTK_GRID (grid), w->labelb[i], 3, i, 1, 1);
		// center align
		gtk_label_set_xalign (GTK_LABEL (w->labelb[i]), 0.5);
		// request minimum size
		gtk_widget_set_size_request (w->labelb[i], 100, 25);

		g_free (buf);
	}
	// create an on/off switch to control the display of values
	w->onOff = gtk_switch_new();
	gtk_switch_set_active (GTK_SWITCH (w->onOff), FALSE);
	gtk_actionable_set_action_name (GTK_ACTIONABLE (w->onOff), "app.enter");
	gtk_header_bar_pack_end (GTK_HEADER_BAR (headerbar), w->onOff);
	// connect actions with callbacks
	g_action_map_add_action_entries (G_ACTION_MAP (w->app), app_actions,
					 G_N_ELEMENTS (app_actions), w);

	gtk_widget_show_all (GTK_WIDGET (w->window));
}

/*!
 * \brief main only creates two threads
 */
int
main (int argc, char *argv[])
{
	int status;
	GThread* producer;
	GThread* consumer;
	GThread* viewer;
	// aggregate all "global required" widgets in a structure - allocate memory
	appWidgets *w = g_malloc (sizeof (appWidgets));

	// initialize the global arrays
	G_LOCK (value);
	for (int i = 0; i < NUM; i++) {
		valuea[i] = -1.0;
		valueb[i] = -1.0;
	}
	G_UNLOCK (value);

	// create some threads that use a timeout() to execute periodically
	// - the producer writes data into two global arrays
	// - the consumer kind of erases all set values
	// - the viewer displays all values on the labels
	producer = g_thread_new ("Producer", (GThreadFunc) producerThread, NULL);
	consumer = g_thread_new ("Consumer", (GThreadFunc) consumerThread, NULL);
	viewer = g_thread_new ("Viewer", (GThreadFunc) viewerThread, (gpointer) w);

	// let's launch the main GUI application
	w->app = gtk_application_new ("org.gtk.threads", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (w->app, "activate", G_CALLBACK (activate), (gpointer) w);
	status = g_application_run (G_APPLICATION (w->app), argc, argv);

	g_thread_join (producer);
	g_thread_join (consumer);
	g_thread_join (viewer);

	// cleanup
	g_object_unref (w->app);
	g_free (w);
	w = NULL;
	return status;
}
/*! EOF */
