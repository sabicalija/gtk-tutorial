#ifndef _cd_app_
#define _cd_app_

#include <gtk/gtk.h>
#include <glib.h>
#include <string.h>
#include <math.h>

typedef struct {
	GtkApplication *app;
	GtkWidget *window;
	GtkWidget *da;
	GtkWidget *button;
	gint xsize;
	gint ysize;
	gint state;
	cairo_t* cr;
} appWidgets;

// on Windows, KDE, XFCE Aqua, etc. set the following value to 0
#define GNOME 1

#endif

