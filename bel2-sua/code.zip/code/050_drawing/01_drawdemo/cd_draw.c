/*!
 * \brief This file contains several functions that showcase some cairo drawing
 *        functions. In particular, the function cd_draw_happyface() showcases
 *        several cairo functions.
 *
 *        TIP: http://cairographics.org/tutorial/
 */
#include "cd_app.h"
#include "cd_draw.h"

/*!
 * \brief cd_draw_lines() draws a number of random lines.
 */
void
cd_draw_lines (gpointer data)
{
	appWidgets *w = (appWidgets*) data;
	cairo_t* cr = w->cr;

	for (int i = 0; i < 100; i++) {
		cairo_set_source_rgb (cr, g_random_double(),
				      g_random_double(),
				      g_random_double());
		cairo_move_to (cr, g_random_double(), g_random_double());
		cairo_line_to (cr, g_random_double(), g_random_double());
		cairo_stroke (cr);
	}
}

/*!
 * \brief cd_draw_rectangles() draws a number of random rectangles.
 */
void
cd_draw_rectangles (gpointer data)
{
	appWidgets *w = (appWidgets*) data;
	cairo_t* cr = w->cr;

	for (int i = 0; i < 100; i++) {
		cairo_set_source_rgb (cr, g_random_double(),
				      g_random_double(),
				      g_random_double());
		cairo_rectangle (cr, g_random_double(), g_random_double(),
				 g_random_double(), g_random_double());
		cairo_stroke (cr);
	}
}

/*!
 * \brief cd_draw_arcs() draws a number of random arcs.
 */
void
cd_draw_arcs (gpointer data)
{
	appWidgets *w = (appWidgets*) data;
	cairo_t* cr = w->cr;

	for (int i = 0; i < 100; i++) {
		cairo_set_source_rgb (cr, g_random_double(),
				      g_random_double(),
				      g_random_double());
		cairo_arc (cr, g_random_double(), g_random_double(),
			   g_random_double(), g_random_double() * 2 * M_PI,
			   g_random_double() * 2 * M_PI);
		cairo_stroke (cr);
	}
}

/*!
 * \brief cd_draw_happyface() draws a fancy "happy face" :-)
 */
void
cd_draw_happyface (gpointer data)
{
	appWidgets *w = (appWidgets*) data;
	cairo_t* cr = w->cr;

	// draw face - blue circle (R G B)
	cairo_set_source_rgb (cr, 0.0, 0.0, 1.0);
	cairo_arc (cr, 0.5, 0.5, 0.45, 0, 2 * M_PI);
	cairo_stroke (cr);
	// draw face - yellow filled circle
	cairo_set_source_rgb (cr, 1.0, 1.0, 0.0);
	cairo_arc (cr, 0.5, 0.5, 0.448, 0, 2 * M_PI);
	cairo_fill (cr);
	// draw mouth - upper lip
	cairo_set_source_rgb (cr, 1.0, 0.0, 0.0);
	cairo_arc (cr, 0.5, 0.45, 0.3, M_PI / 5.0 , 4 * M_PI / 5.0);
	cairo_stroke (cr);
	// draw mouth - lower lip
	cairo_arc (cr, 0.5, 0.5, 0.3, M_PI / 8.0 , 7 * M_PI / 8.0);
	cairo_stroke (cr);
	// draw mouth - smiles
	cairo_move_to (cr, 0.18, 0.6);
	cairo_line_to (cr, 0.28, 0.55);
	cairo_stroke (cr);
	cairo_move_to (cr, 0.82, 0.6);
	cairo_line_to (cr, 0.72, 0.55);
	cairo_stroke (cr);

	// place some text below the face
	cairo_set_source_rgb (cr, 0.5, 0.0, 0.5);
	cairo_select_font_face (cr, "MarckScript",
				CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_font_size (cr, 0.15);
	cairo_move_to (cr, 0.1, 0.93);
	cairo_show_text (cr, "Happy Face");

	// TIP: In order to draw elipses we scale everything in one direction, e.g.,
	// by 0,65 - when we would position the eyes at x=0,4 and x=0,6 we need to
	// put them at x = 0,4/0,65 -> 0,62 and x = 0,6/0,65 -> 0,92
	// NOTE: We save and restore the cairo context before/after the scaled
	//       operation.

	// draw eye - left eye in blue
	cairo_save (cr);
	cairo_set_line_width (w->cr, 0.02);
	cairo_set_source_rgb (cr, 0, 0, 1);
	cairo_scale (cr, 0.65, 1);
	cairo_arc (cr, 0.4 / 0.65, 0.4, 0.05, 0, 2 * M_PI);
	cairo_fill (cr);
	cairo_restore (cr);
	// draw eye - right eye in green
	cairo_save (cr);
	cairo_set_source_rgb (cr, 0, 1, 0);
	cairo_scale (cr, 0.65, 1);
	cairo_arc (cr, 0.6 / 0.65, 0.4, 0.05, 0, 2 * M_PI);
	cairo_fill (cr);
	cairo_restore (cr);
	// draw eye - left pupil in white
	cairo_save (cr);
	cairo_set_line_width (w->cr, 0.02);
	cairo_set_source_rgb (cr, 1, 1, 1);
	cairo_scale (cr, 0.65, 1);
	cairo_arc (cr, 0.4 / 0.65 + 0.025, 0.4, 0.02, 0, 2 * M_PI);
	cairo_fill (cr);
	cairo_restore (cr);
	// draw eye - right pupil in white
	cairo_save (cr);
	cairo_set_source_rgb (cr, 1, 1, 1);
	cairo_scale (cr, 0.65, 1);
	cairo_arc (cr, 0.6 / 0.65 - 0.025, 0.4, 0.02, 0, 2 * M_PI);
	cairo_fill (cr);
	cairo_restore (cr);
}
/*! EOF */

