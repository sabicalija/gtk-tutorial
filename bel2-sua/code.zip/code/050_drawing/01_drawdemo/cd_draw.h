#ifndef _cd_draw_
#define _cd_draw_

#include <gtk/gtk.h>
#include <glib.h>

void cd_draw_happyface (gpointer data);
void cd_draw_lines (gpointer data);
void cd_draw_rectangles (gpointer data);
void cd_draw_arcs (gpointer data);

#endif

