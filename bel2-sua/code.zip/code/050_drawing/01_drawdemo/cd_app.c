/*!
 * \mainpage A simple demonstration program that shows how to create a Gtk+
 *           program that shows how to draw on a cairo drawing area.
 *
 * \author M. Horauer
 * \date   03-12-2015
 */
#include "cd_app.h"
#include "cd_draw.h"

static void
cd_button_callback (GSimpleAction *action, GVariant *parameter, gpointer data);
static gboolean
cd_configure_event (GtkWidget *widget, GdkEventConfigure *event, gpointer data);
static void
cd_draw_callback (GtkWidget *widget, GdkEvent *event, gpointer data);
static void
cd_activate (GtkApplication *app, gpointer data);
static void
cd_quit_callback (GSimpleAction *action, GVariant *parameter, gpointer data);

/*!
 * \brief The callback action for the button simply increments the global state
 *        variable and invokes the cd_draw_callback().
 */
static void
cd_button_callback (GSimpleAction *action, GVariant *parameter, gpointer data)
{
	appWidgets *w = (appWidgets*) data;

	// Switch state - happy face -> lines -> rectangles -> arcs -> happy face ...
	w->state++;
	if (w->state == 4)
		w->state = 0;
	// emit a "draw" signal
	gtk_widget_queue_draw (w->da);
}

/*! 
 * \brief Create a new drawing surface of the appropriate size.
 */
static gboolean
cd_configure_event (GtkWidget *widget, GdkEventConfigure *event, gpointer data)
{
	GtkAllocation allocation;
	static cairo_surface_t *surface = NULL;
	appWidgets *w = (appWidgets*) data;

	gtk_widget_get_allocation (widget, &allocation);
	surface = gdk_window_create_similar_surface (gtk_widget_get_window (widget),
						     CAIRO_CONTENT_COLOR,
						     allocation.width,
						     allocation.height);
	w->cr = cairo_create (surface);
	cairo_destroy (w->cr);
	return TRUE;
}

/*!
 * \brief Redraw the drawing area on resize, creation, window de/activation.
 *        . This function obtains the size of the drawing area.
 *        . Sets the line width.
 *        . Draws a filled rectangle in white.
 *        . Translate and scales the drawing context so that all coordinates
 *          are within (0,0) to (1,1)
 *        . Depending on a global state variable invokes one of several
 *          drawing functions.
 */
static void
cd_draw_callback (GtkWidget *widget, GdkEvent *event, gpointer data)
{
	appWidgets *w = (appWidgets*) data;

	// obtain the size of the drawing area
	w->xsize = gtk_widget_get_allocated_width (w->da);
	w->ysize = gtk_widget_get_allocated_height (w->da);

	cairo_set_line_width (w->cr, 0.005);
	// draw a white filled rectangle
	cairo_set_source_rgb (w->cr, 1.0, 1.0, 1.0);
	cairo_rectangle (w->cr, 0, 0, w->xsize, w->ysize);
	cairo_fill (w->cr);
	// set up a transform so that (0,0) to (1,1) maps to (0, 0) to (width, height)
	cairo_translate (w->cr, 0, 0);
	cairo_scale (w->cr, w->xsize, w->ysize);
	// invoke a drawing function depending on the value of the state variable
	switch (w->state) {
	case 0:
		cd_draw_happyface (w);
		break;
	case 1:
		cd_draw_lines (w);
		break;
	case 2:
		cd_draw_rectangles (w);
		break;
	case 3:
		cd_draw_arcs (w);
		break;
	default:
		break;
	}
}

/*!
 * \brief This callback terminates the application when CTRL+Q is pressed.
 */
static void
cd_quit_callback (GSimpleAction *action, GVariant *parameter, gpointer data)
{
	appWidgets *w = (appWidgets *) data;
	// terminate the application
	g_application_quit (G_APPLICATION (w->app));
}

/*!
 * \brief The following callback constructs the GUI.
 */
static void
cd_activate (GtkApplication *app, gpointer data)
{
#if GNOME
	GtkWidget *headerbar;
	GMenu *appmenu;
#endif
	GtkWidget *box;

	const GActionEntry app_actions[] = {
		{ "enter", cd_button_callback },
		{ "quit", cd_quit_callback }
	};

	appWidgets *w = (appWidgets*) data;

	// define keyboard accelerators
	const gchar *quit_accels[2] = { "<Ctrl>Q", NULL };
	const gchar *redraw_accels[2] = { "<Ctrl>R", NULL };

	// connect keyboard accelerators
	gtk_application_set_accels_for_action (GTK_APPLICATION (app),
					       "app.enter", redraw_accels);
	gtk_application_set_accels_for_action (GTK_APPLICATION (app),
					       "app.quit", quit_accels);

#if GNOME
	// create an application menu available via the GNOME top bar
	appmenu = g_menu_new();
	g_menu_append (appmenu, "_Quit", "app.quit");
	gtk_application_set_app_menu (GTK_APPLICATION (app), G_MENU_MODEL (appmenu));
	g_object_unref (appmenu);
#endif

	// create the top-level window
	w->window = gtk_application_window_new (w->app);
	gtk_window_set_application (GTK_WINDOW (w->window), GTK_APPLICATION (w->app));
	gtk_container_set_border_width (GTK_CONTAINER (w->window), 0);
	gtk_window_set_default_icon_from_file ("sdemo.png", NULL);
	gtk_window_set_title (GTK_WINDOW (w->window), "Cairo Draw Demo");
#if GNOME
	// create a headerbar with client side decorations
	headerbar = gtk_header_bar_new ();
	gtk_widget_show (headerbar);
	gtk_header_bar_set_title (GTK_HEADER_BAR (headerbar), "Demo");
	gtk_header_bar_set_subtitle (GTK_HEADER_BAR (headerbar), "Draw with Cairo");
	gtk_header_bar_set_show_close_button (GTK_HEADER_BAR (headerbar), TRUE);
	gtk_window_set_titlebar (GTK_WINDOW (w->window), headerbar);
#endif
	// create a box and add it to the window
	box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add (GTK_CONTAINER (w->window), box);

	// create a drawing area and place it in the box
	w->da = gtk_drawing_area_new();
	gtk_widget_set_size_request (w->da, 400, 400);
	gtk_box_pack_start (GTK_BOX (box), w->da, TRUE, TRUE, 0);
	// Invoke the cd_draw_callback() whenever a "draw" request signal is emitted.
	// Note: "draw" signals are emitted whenever the focus of a window changes
	//       or when, e.g., gtk_widget_queue_draw() is invoked.
	g_signal_connect (w->da, "draw", G_CALLBACK (cd_draw_callback), (gpointer) w);
	// The configure event is emitted once after start and whenever the window is 
	// resized. The callback creates a drawing surface.
	g_signal_connect (w->da, "configure_event", G_CALLBACK (cd_configure_event), 
	                  (gpointer) w);

	// create a button and place it in the headerbar (GNOME) or below the
	// drawing area
	w->button = gtk_button_new_with_mnemonic ("_Redraw");
	gtk_actionable_set_action_name (GTK_ACTIONABLE (w->button), "app.enter");
#if GNOME
	gtk_header_bar_pack_end (GTK_HEADER_BAR (headerbar), w->button);
#else
	gtk_box_pack_start (GTK_BOX (box), w->button, FALSE, TRUE, 0);
#endif

	// connect actions with callbacks
	g_action_map_add_action_entries (G_ACTION_MAP (w->app), app_actions,
					 G_N_ELEMENTS (app_actions), w);

	gtk_widget_show_all (GTK_WIDGET (w->window));
}

/*!
 * \brief The main() routine simply creates a GtkApplication instance.
 */
int
main (int argc, char *argv[])
{
	gint status;
	// aggregate all "global required" widgets in a structure - allocate memory
	appWidgets *w = g_malloc (sizeof (appWidgets));
	// initialize the state variable
	w->state = 0;
	// let's launch the main GUI application
	w->app = gtk_application_new ("org.gtk.drawdemo", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (w->app, "activate", G_CALLBACK (cd_activate), (gpointer) w);
	status = g_application_run (G_APPLICATION (w->app), argc, argv);
	// cleanup
	g_object_unref (w->app);
	g_free (w);
	w = NULL;
	return status;
}
/*! EOF */

