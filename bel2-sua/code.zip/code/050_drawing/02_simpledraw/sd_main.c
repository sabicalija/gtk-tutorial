#include "sd_main.h"

static void
apply_css (GtkWidget *widget, GtkStyleProvider *provider)
{
	gtk_style_context_add_provider (gtk_widget_get_style_context (widget),
					provider, G_MAXUINT);
	if (GTK_IS_CONTAINER (widget))
		gtk_container_forall (GTK_CONTAINER (widget), (GtkCallback) apply_css,
				      provider);
}

// app activate callback - creates the window
static void
sd_activate (GtkApplication *app, gpointer data)
{
	GtkWidget *window;
	GtkWidget *box;
	GtkWidget *frame;

	struct sdWidgets *mw = (struct sdWidgets *) data;

	// create a top level window and set some properties
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_application (GTK_WINDOW (window), GTK_APPLICATION (app));
	gtk_window_set_title (GTK_WINDOW (window), "Simple Drawing Program");
	gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
	gtk_window_set_default_icon_from_file ("icons/icon.png", NULL);
	gtk_window_set_default_size (GTK_WINDOW (window), 805, 642);
	gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);

	box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_container_add (GTK_CONTAINER (window), box);

	frame = gtk_frame_new (NULL);
	gtk_frame_set_shadow_type (GTK_FRAME (frame), GTK_SHADOW_IN);
	gtk_box_pack_start (GTK_BOX (box), frame, FALSE, FALSE, 0);

	// CONSTRUCT a TOOLBAR
	sd_construct_toolbar (frame, mw);
	// add a fancy background image to the frame
	GtkStyleProvider *provider;
	provider = GTK_STYLE_PROVIDER (gtk_css_provider_new ());
	gtk_css_provider_load_from_resource (GTK_CSS_PROVIDER (provider),
					     "/css_sd/css_sd.css");
	apply_css (window, provider);

	// CONSTRUCT a DRAWING AREA
	sd_construct_drawing_area (box, mw);

	// show all widgets
	gtk_widget_show_all (GTK_WIDGET (window));
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	// we need some memory for the widgets struct
	struct sdWidgets *mw = g_malloc (sizeof (struct sdWidgets));

	// initialize some default settings
	mw->drawmode = DRAWOFF;
	mw->gridmode = GRIDOFF;

	// create a threaded application
	app = gtk_application_new ("org.gtk.simpledraw", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (sd_activate), (gpointer) mw);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	// free the memory for the widgets struct
	g_free (mw);
	// free the single linked list
	g_slist_free (listObjects);
	return status;
}
/** EOF */
