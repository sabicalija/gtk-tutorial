#ifndef _sd_common_
#define _sd_common_

#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

typedef enum {DRAWOFF, DRAWLINE, DRAWRECT} draw_state;
typedef enum {GRIDOFF, GRIDON} grid_state;

struct sdWidgets {
	GtkWidget *draw_line_button;
	GtkWidget *draw_rect_button;
	GtkWidget *drawing_area;
	cairo_surface_t *surface;
	cairo_t *cr;
	gint win_xsize;
	gint win_ysize;
	draw_state drawmode;
	grid_state gridmode;
};

#endif
/** EOF */
