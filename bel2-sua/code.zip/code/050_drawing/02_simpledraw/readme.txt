In order to see the debug messages run the program as follows:

....
G_MESSAGES_DEBUG=all ./sd_demo
....

The program has several shortcommings (apart from functional issues) that need fixing:

- several global variables
- it leaks some memory

================
[TIP]

Checkout https://wiki.gnome.org/Valgrind

....
valgrind --tool=memcheck --leak-check=full --leak-resolution=high --num-callers=20 --log-file=vgdump ./sd_demo
....

================
