#include "sd_drawing.h"

#define GRIDSIZE 10

// in this demo we use some globals - this is ugly and should be avoided
gint x = 0;
gint y = 0;
gint x_pos_clicked;
gint y_pos_clicked;
gint x_pos_release;
gint y_pos_release;
gboolean on_the_move;
drawing_object *pDrawObj;
GSList *listObjects;

// The following callback gets executed whenever a "configure" signal is issued.
// This is done upon window creation and whenever the window is modified (i.e.
// it's size).
gboolean
sd_configure_event (GtkWidget *widget, GdkEventConfigure *event, gpointer data)
{
	GtkAllocation allocation;
	struct sdWidgets *mw = (struct sdWidgets *) data;

	if (mw->surface)
		cairo_surface_destroy (mw->surface);
	gtk_widget_get_allocation (widget, &allocation);
	mw->surface = gdk_window_create_similar_surface (gtk_widget_get_window (widget),
							 CAIRO_CONTENT_COLOR,
							 allocation.width,
							 allocation.height);
	mw->cr = cairo_create (mw->surface);
	cairo_destroy (mw->cr);
	return TRUE;
}

// The following function is invoked for every node of our single linked list.
// It does the following steps:
// - It reads the type (here either a line 'l' or a rectangle 'r')
// - Depending on this value it draws eirther a line using
//   cairo_move_to() followed by cairo_line_to() and cairo_stroke() or a
//   rectangle using cairo_rectangle() followed by cairo_stroke()
static void
drawObjects (gpointer data, gpointer user_data)
{
	struct sdWidgets *mw = (struct sdWidgets *) user_data;
	// draw a stored line
	if ( ( (drawing_object *) data)->type == 'l') {
		cairo_move_to (mw->cr, ( (drawing_object *) data)->srcx,
			       ( (drawing_object *) data)->srcy);
		cairo_line_to (mw->cr, ( (drawing_object *) data)->dstx,
			       ( (drawing_object *) data)->dsty);
		cairo_stroke (mw->cr);
	}
	// draw a stored rectangle
	if ( ( (drawing_object *) data)->type == 'r') {
		cairo_rectangle (mw->cr, ( (drawing_object *) data)->srcx,
				 ( (drawing_object *) data)->srcy,
				 ( (drawing_object *) data)->dstx - ( (drawing_object *) data)->srcx,
				 ( (drawing_object *) data)->dsty - ( (drawing_object *) data)->srcy);
		cairo_stroke (mw->cr);
	}
}

// The "draw" callback callback is invoked whenever the "draw" signal is
// emitted. This occurs when the window is hidden, shown, created, etc. In this
// callback we do the following things every time:
// - We obtain the size of the drawing area
// - We paint the entire background of the drawing area in white using
//   cairo_rectangle() followed by cairo_fill()
// - When active we draw the grid - starting at (0,0) we draw a small rectangle
//   at points spaced apart by GRIDSIZE
// - Next, we select a line width and a colour for our objects
// - We redraw all stored (in our single linked list) objects using
//   drawObjects()
// - In case the button is not released - we draw our final object from the
//   source x/y to the actual x/y position
gboolean
sd_draw_event (GtkWidget *widget, GdkEvent *event, gpointer data)
{
	gint i, k;
	struct sdWidgets *mw = (struct sdWidgets *) data;

	// obtain the size of the drawing area
	mw->win_xsize = gtk_widget_get_allocated_width (mw->drawing_area);
	mw->win_ysize = gtk_widget_get_allocated_height (mw->drawing_area);
	// draw a white filled rectangle
	cairo_set_source_rgb (mw->cr, 1.0, 1.0, 1.0);
	cairo_rectangle (mw->cr, 0, 0, mw->win_xsize, mw->win_ysize);
	cairo_fill (mw->cr);
	// draw the grid
	if (mw->gridmode == GRIDON) {
		// set GREEN as grid colour
		cairo_set_source_rgb (mw->cr, 0.0, 0.5, 0.0);
		// set a line width for the grid
		cairo_set_line_width (mw->cr, 0.1);
		for (i = 0; i < mw->win_xsize; i += GRIDSIZE) {
			for (k = 0; k < mw->win_ysize; k += GRIDSIZE) {
				cairo_rectangle (mw->cr, i, k, 1, 1);
				cairo_stroke (mw->cr);
			}
		}
	}
	// set a line width for drawing objects
	cairo_set_line_width (mw->cr, 1);
	// set BLUE as drawing colour
	cairo_set_source_rgb (mw->cr, 0.0, 0.0, 1.0);
	// redraw all objects (lines & rectangles) we created so far
	g_slist_foreach (listObjects, (GFunc) drawObjects, (gpointer) mw);
	// we draw either a line or a rectangle to the position of the pointer
	if (on_the_move == TRUE) {
		if (mw->drawmode == DRAWLINE) {
			cairo_move_to (mw->cr, x_pos_clicked, y_pos_clicked);
			if (mw->gridmode == GRIDOFF)
				cairo_line_to (mw->cr, x, y);
			if (mw->gridmode == GRIDON)
				cairo_line_to (mw->cr, x - x % GRIDSIZE, y - y % GRIDSIZE);
			cairo_stroke (mw->cr);
		}
		if (mw->drawmode == DRAWRECT) {
			if (mw->gridmode == GRIDOFF)
				cairo_rectangle (mw->cr, x_pos_clicked, y_pos_clicked,
						 x - x_pos_clicked, y - y_pos_clicked);
			if (mw->gridmode == GRIDON)
				// stick to the next grid item (ugly solution)
				cairo_rectangle (mw->cr, x_pos_clicked, y_pos_clicked,
						 (x - x_pos_clicked) - (x - x_pos_clicked) % GRIDSIZE,
						 (y - y_pos_clicked) - (y - y_pos_clicked) % GRIDSIZE);
			cairo_stroke (mw->cr);
		}
	}
	/* We've handled the event, stop processing */
	return TRUE;
}

// The following mouse button press event callback is invoked whenever the
// primary mouse button is pressed. All we do is we obtain the x/y coordinates
// and store them in a global variable.
// When the grid is active we stick the value to the nearest top left grid
// point - this is a bit uggly - we could round the value and stick to the
// nearest point.
gboolean
sd_button_press_event (GtkWidget *widget, GdkEventButton *event, gpointer data)
{
	struct sdWidgets *mw = (struct sdWidgets *) data;

	g_debug ("Left Button Click @ (%d, %d)", (gint) event->x, (gint) event->y);
	if (event->button == GDK_BUTTON_PRIMARY) {
		if (mw->gridmode == GRIDOFF) {
			x_pos_clicked = (gint) event->x;
			y_pos_clicked = (gint) event->y;
		}
		if (mw->gridmode == GRIDON) {
			// stick the values to the next grid item (ugly solution)
			x_pos_clicked = ( (gint) (event->x) - (gint) (event->x) % GRIDSIZE);
			y_pos_clicked = ( (gint) (event->y) - (gint) (event->y) % GRIDSIZE);
		}
	}
	/* We've handled the event, stop processing */
	return TRUE;
}

// The following callback function is invoked whenever button1 is moved around
// while the button is pressed. We do the following things:
// - Obtain the position using gdk_window_get_device_position()
// - We redraw all objects stored in our single linked list using drawObjects()
// - We draw a line or a rectangle (kind of a rubber line) from the source
//   position to the one where the pointer is right now
// - We emit a "draw" signal so that everything is redrawn
gboolean
sd_button_move_event (GtkWidget *widget, GdkEventMotion *event, gpointer data)
{
	GdkModifierType state;
	struct sdWidgets *mw = (struct sdWidgets *) data;

	// obtain the pointer position
	gdk_window_get_device_position (event->window, event->device, &x, &y, &state);
	if (state & GDK_BUTTON1_MASK) {
		// redraw all objects
		g_slist_foreach (listObjects, (GFunc) drawObjects, (gpointer) mw);
		// draw a line or rectangle
		if (mw->drawmode == DRAWLINE) {
			// we draw a line from the last recorded click position to the actual
			// position of the mouse pointer
			cairo_move_to (mw->cr, x_pos_clicked, y_pos_clicked);
			if (mw->gridmode == GRIDOFF)
				cairo_line_to (mw->cr, (gint) x, (gint) y);
			if (mw->gridmode == GRIDON)
				// stick to the next grid item (ugly solution)
				cairo_line_to (mw->cr, ( (gint) x - (gint) x % GRIDSIZE),
					       ( (gint) y - (gint) y % GRIDSIZE));
			cairo_stroke (mw->cr);
		}
		if (mw->drawmode == DRAWRECT) {
			// DEBUG output - print the position where the pointer is
			g_debug ("Pressed pointing @ (%d, %d)", (gint) x, (gint) y);
			// we draw a rectangle from the last recorded click position to the actual
			// position of the mouse cursor
			if (mw->gridmode == GRIDOFF)
				cairo_rectangle (mw->cr, x_pos_clicked, y_pos_clicked,
						 x_pos_clicked - (gint) x,
						 y_pos_clicked - (gint) y);
			if (mw->gridmode == GRIDON)
				cairo_rectangle (mw->cr, x_pos_clicked, y_pos_clicked,
						 (x_pos_clicked - (gint) x) % GRIDSIZE,
						 (y_pos_clicked - (gint) y) % GRIDSIZE);
			cairo_stroke (mw->cr);
		}
	}
	on_the_move = TRUE;
	// emit a "draw" signal
	gtk_widget_queue_draw (mw->drawing_area);
	/* We've handled the event, stop processing */
	return TRUE;
}

// function that prints the elements of a node of a single linked list
void printoutObjects (gpointer data, gpointer user_data)
{
	g_debug ("Object: %c SRC (%d,%d) DST (%d, %d)",
		 ( (drawing_object *) data)->type,
		 ( (drawing_object *) data)->srcx,
		 ( (drawing_object *) data)->srcy,
		 ( (drawing_object *) data)->dstx,
		 ( (drawing_object *) data)->dsty
		);
}

// The following release callback is executed whenever the left mouse button is
// released. In this case we add the SRC and DST x/y values to a single linked
// list. At the end of this function we emit a "draw" signal so that all objects
// are redrawn.
gboolean
sd_button_release_event (GtkWidget *widget, GdkEventButton *event, gpointer data)
{
	struct sdWidgets *mw = (struct sdWidgets *) data;

	g_debug ("Release Left Button @ (%d, %d)", (gint) event->x, (gint) event->y);
	if (event->button == GDK_BUTTON_PRIMARY) {
		x_pos_release = (gint) event->x;
		y_pos_release = (gint) event->y;
		// add the now complete object to a single linked list
		// - obtain memory for the structure
		pDrawObj = g_new (drawing_object, 1);
		// - fill in the structure
		if (mw->drawmode == DRAWLINE)
			pDrawObj->type = 'l';
		if (mw->drawmode == DRAWRECT)
			pDrawObj->type = 'r';
		pDrawObj->srcx = x_pos_clicked;
		pDrawObj->srcy = y_pos_clicked;
		if (mw->gridmode == GRIDOFF) {
			pDrawObj->dstx = x_pos_release;
			pDrawObj->dsty = y_pos_release;
		}
		if (mw->gridmode == GRIDON) {
			pDrawObj->dstx = x_pos_release - x_pos_release % GRIDSIZE;
			pDrawObj->dsty = y_pos_release - y_pos_release % GRIDSIZE;
		}
		// - append it to the single linked list
		listObjects = g_slist_append (listObjects, pDrawObj);
		// DEBUG output - print the entire list of objects
		g_slist_foreach (listObjects, (GFunc) printoutObjects, NULL);
	}
	on_the_move = FALSE;
	// emit a "draw" signal
	gtk_widget_queue_draw (mw->drawing_area);
	/* We've handled it, stop processing */
	return FALSE;
}

// The following function is used to construct and setup the drawing area. Note
// the various callbacks.
// - The "draw" signal triggers a callback that is invoked whenever the window
//   needs to be redrawn - here we need to redraw all elements all over again.
// - The "configure" signal triggers a callback that is invoked whenever the
//   size of the window changes as well as when it is constructed the first
//   time.
// - The "button-press-event" signal is emitted whenever the left button is
//   pressed. Here we store the x/y values of the coordinates.
// - The "motion-notify-event" signal is emitted whenever we move the mouse with
//   the left button held pressed (to that end the GDB_BUTTON1_MOTION_MASK is
//   required). In the respective callback we redraw all objects of the linked
//   list and additionally a line or a rectangle from the position where the
//   pointer was pressed up to the actual position.
// - The "button-release-event" signal is emitted when we release the left mouse
//   button. In the callback the source and destination x/y values are added to
//   the single linked list and a "draw" signal is emitted.
void
sd_construct_drawing_area (GtkWidget *box, struct sdWidgets *mw)
{
	// DRAWING AREA
	mw->drawing_area = gtk_drawing_area_new ();
	gtk_widget_set_vexpand (mw->drawing_area, TRUE);
	gtk_box_pack_start (GTK_BOX (box), mw->drawing_area, TRUE, TRUE, 0);
	// - Signals used to handle backing surface
	g_signal_connect (mw->drawing_area, "draw",
			  G_CALLBACK (sd_draw_event), (gpointer) mw);
	g_signal_connect (mw->drawing_area, "configure-event",
			  G_CALLBACK (sd_configure_event), (gpointer) mw);
	// - Event signals
	g_signal_connect (mw->drawing_area, "button-press-event",
			  G_CALLBACK (sd_button_press_event), (gpointer) mw);
	g_signal_connect (mw->drawing_area, "motion-notify-event",
			  G_CALLBACK (sd_button_move_event), (gpointer) mw);
	g_signal_connect (mw->drawing_area, "button-release-event",
			  G_CALLBACK (sd_button_release_event), (gpointer) mw);
	// - Ask to receive a typical events
	// -- see /usr/include/gtk-3.0/gdk/gdkevents.h
	gtk_widget_set_events (mw->drawing_area,
			       gtk_widget_get_events (mw->drawing_area)
			       | GDK_LEAVE_NOTIFY_MASK
			       | GDK_BUTTON_PRESS_MASK
			       | GDK_BUTTON1_MOTION_MASK
			       | GDK_BUTTON_RELEASE_MASK
			      );
}
/** EOF */
