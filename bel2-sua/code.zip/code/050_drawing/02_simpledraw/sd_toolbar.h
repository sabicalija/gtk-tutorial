#ifndef _sd_toolbar_
#define _sd_toolbar_

#include "sd_main.h"

void
sd_construct_toolbar (GtkWidget *frame, struct sdWidgets *mw);

#endif
/** EOF */
