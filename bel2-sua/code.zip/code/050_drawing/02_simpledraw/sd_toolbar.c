#include "sd_toolbar.h"

// Below is the callback for the grid toolbar button. Depending on it's state
// it displays different images, sets a variable and emits a "draw" signal.
void
sd_grid_button_cb (GtkWidget *widget, gpointer data)
{
	gboolean state;
	GtkWidget *img;
	struct sdWidgets *mw = (struct sdWidgets *) data;

	state = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget));
	if (state == FALSE) {
		g_debug ("Grid Off");
		mw->gridmode = GRIDOFF;
		img = gtk_image_new_from_file ("icons/grid_off.png");
		gtk_button_set_image (GTK_BUTTON (widget), img);
		gtk_widget_queue_draw (mw->drawing_area);
	} else {
		g_debug ("Grid On");
		mw->gridmode = GRIDON;
		img = gtk_image_new_from_file ("icons/grid_on.png");
		gtk_button_set_image (GTK_BUTTON (widget), img);
		gtk_widget_queue_draw (mw->drawing_area);
	}
}

// Below the callback for the line toolbar button. It essentially sets a
// variable and kind of untoggles the rectangle toolbar button.
void
sd_draw_line_cb (GtkWidget *widget, gpointer data)
{
	gboolean state;
	struct sdWidgets *mw = (struct sdWidgets *) data;


	state = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget));
	if (state == FALSE) {
		g_debug ("Draw Off");
		mw->drawmode = DRAWOFF;
	} else {
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (mw->draw_rect_button),
					      FALSE);
		g_debug ("Draw Line");
		mw->drawmode = DRAWLINE;
	}
}

// Below the callback for the rectangle toolbar button. It essentially sets a
// variable and kind of untoggles the line toolbar button.
void
sd_draw_rect_cb (GtkWidget *widget, gpointer data)
{
	gboolean state;
	struct sdWidgets *mw = (struct sdWidgets *) data;


	state = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget));
	if (state == FALSE) {
		mw->drawmode = DRAWOFF;
		g_debug ("Draw Off");
	} else {
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (mw->draw_line_button),
					      FALSE);
		mw->drawmode = DRAWRECT;
		g_debug ("Draw Rect");
	}
}

// The followin function constructs the toolbar that is put into a frame
// container within a box. It uses some toggle_buttons along with isome images
// and some tooltips - nothing special here.
void
sd_construct_toolbar (GtkWidget *frame, struct sdWidgets *mw)
{
	GtkWidget *toolbar_box;
	GtkWidget *grid_button;
	GtkWidget *grid_img, *line_img, *rect_img;

	// TOOLBAR
	toolbar_box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add (GTK_CONTAINER (frame), toolbar_box);
	g_object_set (toolbar_box, "margin", 0, NULL);
	gtk_style_context_add_class (gtk_widget_get_style_context (toolbar_box),
				     GTK_STYLE_CLASS_LINKED);

	// GRID toolbar button
	grid_button = gtk_toggle_button_new ();
	grid_img = gtk_image_new_from_file ("icons/grid_off.png");
	gtk_button_set_image (GTK_BUTTON (grid_button), grid_img);
	gtk_widget_set_tooltip_text (grid_button, "Toggles the grid on/off");
	gtk_container_add (GTK_CONTAINER (toolbar_box), grid_button);
	g_signal_connect (G_OBJECT (grid_button), "toggled",
			  G_CALLBACK (sd_grid_button_cb), (gpointer) mw);

	// DRAW LINE button
	mw->draw_line_button = gtk_toggle_button_new ();
	line_img = gtk_image_new_from_file ("icons/draw_on.png");
	gtk_button_set_image (GTK_BUTTON (mw->draw_line_button), line_img);
	gtk_widget_set_tooltip_text (mw->draw_line_button, "Draw a line");
	gtk_container_add (GTK_CONTAINER (toolbar_box), mw->draw_line_button);
	g_signal_connect (G_OBJECT (mw->draw_line_button), "toggled",
			  G_CALLBACK (sd_draw_line_cb), (gpointer) mw);
	// DRAW RECTANGLE button
	mw->draw_rect_button = gtk_toggle_button_new ();
	rect_img = gtk_image_new_from_file ("icons/draw_rect.png");
	gtk_button_set_image (GTK_BUTTON (mw->draw_rect_button), rect_img);
	gtk_widget_set_tooltip_text (mw->draw_rect_button, "Draw a rectangle");
	gtk_container_add (GTK_CONTAINER (toolbar_box), mw->draw_rect_button);
	g_signal_connect (G_OBJECT (mw->draw_rect_button), "toggled",
			  G_CALLBACK (sd_draw_rect_cb), (gpointer) mw);
}
/** EOF */
