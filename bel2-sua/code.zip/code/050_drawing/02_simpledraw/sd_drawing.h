#ifndef _sd_drawing_
#define _sd_drawing_

#include "sd_main.h"

typedef struct {
	gchar type;
	gint srcx;
	gint srcy;
	gint dstx;
	gint dsty;
} drawing_object;

extern GSList *listObjects;

gboolean
sd_configure_event (GtkWidget *widget, GdkEventConfigure *event, gpointer data);
gboolean
sd_draw_event (GtkWidget *widget, GdkEvent *event, gpointer data);
gboolean
sd_button_press_event (GtkWidget *widget, GdkEventButton *event, gpointer data);
gboolean
sd_button_move_event (GtkWidget *widget, GdkEventMotion *event, gpointer data);
gboolean
sd_button_release_event (GtkWidget *widget, GdkEventButton *event, gpointer data);
void
sd_construct_drawing_area (GtkWidget *box, struct sdWidgets *mw);

#endif
/** EOF */
