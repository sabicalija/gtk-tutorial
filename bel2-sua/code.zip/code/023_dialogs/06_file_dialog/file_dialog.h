#ifndef _file_dialog_
#define _file_dialog_

#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

struct myWidgets {
	GtkWidget *window;
	GtkWidget *label;
};

void file_open_dialog_cb (GtkWidget *widget, gpointer user_data);
void file_save_dialog_cb (GtkWidget *widget, gpointer user_data);

#endif
