#include <file_dialog.h>

/*
 * File Open Dialog
 */
void
file_open_dialog_cb (GtkWidget *widget, gpointer user_data)
{
	GtkWidget               *chooser;
	gchar                   *filename = NULL;
	gchar *fn;
	struct myWidgets *mw = (struct myWidgets *) user_data;

	chooser = gtk_file_chooser_dialog_new ("Open File ...",
					       GTK_WINDOW (mw->window),
					       GTK_FILE_CHOOSER_ACTION_OPEN,
					       "_Cancel", GTK_RESPONSE_CANCEL,
					       "_Open", GTK_RESPONSE_ACCEPT,
					       NULL);

	if (gtk_dialog_run (GTK_DIALOG (chooser)) == GTK_RESPONSE_ACCEPT) {
		// get the selected filename and path
		filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (chooser));
		// the following lines remove the path from the filename
		if (filename[ (g_utf8_strlen (filename, 256) - 1)] == '/')
			filename[ (g_utf8_strlen (filename, 256) - 1)] = '\0';
		fn = g_utf8_strrchr (filename, g_utf8_strlen (filename, 256), '/');
		if (fn != NULL)
			fn++;
		else
			fn = filename;
		// display only the filename on the label
		gtk_label_set_text (GTK_LABEL (mw->label), fn);
	}
	gtk_widget_destroy (chooser);
}

/*
 * File Save Dialog
 */
void
file_save_dialog_cb (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *chooser;
	gchar *filename = NULL;
	GtkFileFilter *filter;
	struct myWidgets *mw = (struct myWidgets *) user_data;

	chooser = gtk_file_chooser_dialog_new ("File Save ...",
					       GTK_WINDOW (mw->window),
					       GTK_FILE_CHOOSER_ACTION_OPEN,
					       "_Cancel", GTK_RESPONSE_CANCEL,
					       "_Save", GTK_RESPONSE_ACCEPT,
					       NULL);
	// we add a custom file pattern
	filter = gtk_file_filter_new();
	gtk_file_filter_set_name (filter, "AsciiDoc");
	gtk_file_filter_add_pattern (filter, "*.asciidoc");
	gtk_file_chooser_add_filter (GTK_FILE_CHOOSER (chooser), filter);

	// see e.g., https://wiki.selfhtml.org/wiki/MIME-Type/%C3%9Cbersicht
	// for a list of common mime types
	filter = gtk_file_filter_new();
	gtk_file_filter_set_name (filter, "Text");
	gtk_file_filter_add_mime_type (filter, "text/plain");
	gtk_file_chooser_add_filter (GTK_FILE_CHOOSER (chooser), filter);
	// make this filter the default
	gtk_file_chooser_set_filter (GTK_FILE_CHOOSER (chooser), filter);

	if (gtk_dialog_run (GTK_DIALOG (chooser)) == GTK_RESPONSE_ACCEPT) {
		// get the selected filename and path and display it on the label
		filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (chooser));
		gtk_label_set_text (GTK_LABEL (mw->label), filename);
	}

	gtk_widget_destroy (chooser);
}
/** EOF */

