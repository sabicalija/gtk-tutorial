#include <file_dialog.h>

static void
activate (GtkApplication *app, gpointer user_data)
{
	GtkWidget *grid;
	GtkWidget *fopen_button;
	GtkWidget *fsave_button;
	struct myWidgets *mw = (struct myWidgets *) user_data;

	mw->window = gtk_application_window_new (app);
	gtk_window_set_default_size (GTK_WINDOW (mw->window), 700, 200);
	gtk_window_set_title (GTK_WINDOW (mw->window), "File Open & Save Demo");
	grid = gtk_grid_new();
	gtk_container_add (GTK_CONTAINER (mw->window), grid);
	gtk_container_set_border_width (GTK_CONTAINER (mw->window), 20);
	gtk_grid_set_row_homogeneous (GTK_GRID (grid), TRUE);
	gtk_grid_set_column_homogeneous (GTK_GRID (grid), TRUE);
	mw->label = gtk_label_new ("Click the button");
	gtk_grid_attach (GTK_GRID (grid), mw->label, 0, 0, 1, 1);
	fopen_button = gtk_button_new_with_label ("File Open Dialog");
	gtk_grid_attach (GTK_GRID (grid), fopen_button, 0, 1, 1, 1);
	g_signal_connect (fopen_button, "clicked", G_CALLBACK (file_open_dialog_cb), mw);
	fsave_button = gtk_button_new_with_label ("File Save Dialog");
	gtk_grid_attach (GTK_GRID (grid), fsave_button, 0, 2, 1, 1);
	g_signal_connect (fsave_button, "clicked", G_CALLBACK (file_save_dialog_cb), mw);

	gtk_widget_show_all (mw->window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	struct myWidgets *mw = g_malloc (sizeof (struct myWidgets));

	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), mw);
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);
	g_free (mw);

	return status;
}
/** EOF */
