#ifndef _uart_dialog_
#define _uart_dialog_

#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

enum parity {NONE, EVEN, ODD};
enum hwcheck {HWCHECKON, HWCHECKOFF};
enum swcheck {SWCHECKON, SWCHECKOFF};

struct myWidgets {
	GtkWidget *window;
	GtkWidget *dialog;
	GtkWidget *label;
	GtkWidget *device_combo;
	GtkWidget *baudrate_combo;
	GtkWidget *parity_combo;
	GtkWidget *databits_spinb;
	GtkWidget *stopbits_spinb;
	GtkWidget *hw_check;
	GtkWidget *sw_check;
	gchar *status_device;
	gint status_baudrate;
	enum  parity status_parity;
	gint status_databits;
	gint status_stopbits;
	enum  hwcheck status_hwcheck;
	enum  swcheck status_swcheck;
	gboolean initial;
	gint idd;
	gint idb;
};

void initial_uart_config (struct myWidgets *mw);
void on_response (GtkDialog *dialog, gint response_id, gpointer user_data);
void dialog_cb (GtkWidget *widget, gpointer user_data);

#endif
