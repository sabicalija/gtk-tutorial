#include <uart_dialog.h>

static void
activate (GtkApplication *app, gpointer user_data)
{
	GtkWidget *grid;
	GtkWidget *button;
	struct myWidgets *mw = (struct myWidgets *) user_data;

	mw->window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (mw->window), "UART Dialog DEMO Example");
	grid = gtk_grid_new();
	gtk_container_add (GTK_CONTAINER (mw->window), grid);
	gtk_container_set_border_width (GTK_CONTAINER (mw->window), 70);
	gtk_grid_set_row_homogeneous (GTK_GRID (grid), TRUE);
	gtk_grid_set_column_homogeneous (GTK_GRID (grid), TRUE);
	mw->label = gtk_label_new ("Click the button");
	gtk_widget_set_size_request (mw->label, 150, 40);
	gtk_grid_attach (GTK_GRID (grid), mw->label, 0, 0, 1, 1);
	button = gtk_button_new_with_label ("Show Dialog");
	gtk_widget_set_size_request (button, 150, 40);
	gtk_grid_attach (GTK_GRID (grid), button, 0, 1, 1, 1);

	// in the button callback we realize the UART settings dialog
	g_signal_connect (button, "clicked", G_CALLBACK (dialog_cb), mw);
	// initialize UART default configuration
	initial_uart_config (mw);

	gtk_widget_show_all (mw->window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	struct myWidgets *mw = g_malloc (sizeof (struct myWidgets));

	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), mw);
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);
	g_free (mw);

	return status;
}
/** EOF */
