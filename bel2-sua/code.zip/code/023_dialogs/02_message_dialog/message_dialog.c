#include <gtk/gtk.h>

struct myWidgets {
	GtkWidget *window;
	GtkWidget *label;
};

static void
on_response (GtkDialog *dialog, gint response_id, gpointer user_data)
{
	struct myWidgets *mw = (struct myWidgets *) user_data;
	
	/* If the button clicked gives response OK (response_id being -5) */
	if (response_id == GTK_RESPONSE_OK)
		gtk_label_set_text (GTK_LABEL (mw->label), "OK clicked!");
	/* If the message dialog is destroyed (for example by pressing escape) */
	else if (response_id == GTK_RESPONSE_DELETE_EVENT)
		gtk_label_set_text (GTK_LABEL (mw->label), "Dialog closed!");

	/* Destroy the dialog after one of the above actions have taken place */
	gtk_widget_destroy (GTK_WIDGET (dialog));
}

/* 
 * Message Dialog
 */
static void
message_cb (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *message_dialog;
	struct myWidgets *mw = (struct myWidgets *) user_data;

	/* Create a new message dialog, and set the parameters as follows:
	 * Dialog Flags - make the constructed dialog modal
	 * (modal windows prevent interaction with other windows in the application)
	 * Message Type - nonfatal warning message
	 * Buttons Type - use the ok and cancel buttons
	 * message_format - text that you want the user to see in the window
	 */
	message_dialog = gtk_message_dialog_new (GTK_WINDOW (mw->window),
						 GTK_DIALOG_MODAL,
						 GTK_MESSAGE_WARNING,
						 GTK_BUTTONS_OK_CANCEL,
						 "Hello from a message dialog!");
	/* display the message dialog */
	gtk_widget_show_all (message_dialog);
	/* connect the response signal */
	g_signal_connect (GTK_DIALOG (message_dialog), "response",
			  G_CALLBACK (on_response), mw);
}

static void
activate (GtkApplication *app, gpointer user_data)
{
	GtkWidget *grid;
	GtkWidget *button;
	struct myWidgets *mw = (struct myWidgets *) user_data;

	/* Create a window with a title and a default size */
	mw->window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (mw->window), "Message Dialog Example");
	gtk_window_set_default_icon_from_file ("icon.png", NULL);
	/* add a label and a button to the window */
	grid = gtk_grid_new();
	gtk_container_add (GTK_CONTAINER (mw->window), grid);
	gtk_container_set_border_width (GTK_CONTAINER (mw->window), 70);
	gtk_grid_set_row_homogeneous (GTK_GRID (grid), TRUE);
	gtk_grid_set_column_homogeneous (GTK_GRID (grid), TRUE);
	mw->label = gtk_label_new ("Click the button");
	gtk_widget_set_size_request (mw->label, 150, 40);
	gtk_grid_attach (GTK_GRID (grid), mw->label, 0, 0, 1, 1);
	button = gtk_button_new_with_label ("Show Message Dialog");
	gtk_widget_set_size_request (button, 150, 40);
	gtk_grid_attach (GTK_GRID (grid), button, 0, 1, 1, 1);
	/* connect a callback to the button click */
	g_signal_connect (button, "clicked", G_CALLBACK (message_cb), mw);
	/* show the window */
	gtk_widget_show_all (mw->window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;
	struct myWidgets *mw = g_malloc (sizeof (struct myWidgets));

	app = gtk_application_new ("org.gtk.messagedialog", G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), mw);
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);
	g_free (mw);

	return status;
}
/** EOF */
