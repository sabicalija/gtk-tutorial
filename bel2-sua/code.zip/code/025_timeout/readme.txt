(1) Create the C Code.

(2) Reference all resources (text files, images, fonts) from a gresource file
using XML syntax.

(3) Generate the C file from the XML file using something like

glib-compile-resources --sourcedir=. timeout_res.gresource.xml --generate-source

(4) Include the resource file in your build process, e.g.:

gcc timeout.c timeout_res.c -lm `pkg-config --cflags --libs gtk+-3.0` -Wall -g -o timeout

