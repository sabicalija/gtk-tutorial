#include <gtk/gtk.h>
#include <string.h>

static guint animate_label (gpointer data);
static void activate (GtkApplication* app, gpointer user_data);

// callback executed repeatedly after timeout as long as it returns TRUE
static guint
animate_label (gpointer data)
{
	gchar *buffer, tmp;
	guint i;
	GtkWidget *label = GTK_WIDGET (data);

	// obtain text from the label
	buffer = (gchar*) gtk_label_get_text (GTK_LABEL (label));
	// rotate one char from left to right
	tmp = buffer[0];
	for (i = 0; i < strlen (buffer); i++)
		buffer[i] = buffer[i + 1];
	buffer[strlen (buffer)] = tmp;
	// write the rotated text to the label
	gtk_label_set_text (GTK_LABEL (label), buffer);

	return TRUE;
}

static void
apply_css (GtkWidget *widget, GtkStyleProvider *provider)
{
	gtk_style_context_add_provider (gtk_widget_get_style_context (widget),
					provider, G_MAXUINT);
	if (GTK_IS_CONTAINER (widget))
		gtk_container_forall (GTK_CONTAINER (widget), (GtkCallback) apply_css,
				      provider);
}

// app activate callback - creates the window
static void
activate (GtkApplication* app, gpointer user_data)
{
	GtkWidget *window;
	GtkWidget *label;
	GtkStyleProvider *provider;

	// create the window and set a title
	window = gtk_application_window_new (app);
	gtk_window_set_title (GTK_WINDOW (window), "Basic Animation");

	label = gtk_label_new ("Hello World! ");
	gtk_container_add (GTK_CONTAINER (window), label);
	// name the label so that we can reference it from the CSS file
	gtk_widget_set_name(label, "label_output");

	// since we shift a whole character per time, it's better to use
	// a monospace font, so that the shifting seems done at the same pace
	provider =  GTK_STYLE_PROVIDER (gtk_css_provider_new ());
	gtk_css_provider_load_from_resource (GTK_CSS_PROVIDER (provider), 
	                                     "/css_timeout/css_timeout.css");
	apply_css (window, provider);
	g_object_unref (provider);

	// Install the timeout - it will repeately invoke the function
	// "animate_label" with the data "label" after approx. 250ms as long
	// as the function itself returns TRUE.
	g_timeout_add (250, (GSourceFunc) animate_label, (gpointer) label);
	gtk_widget_show_all (window);
}

int
main (int argc, char **argv)
{
	GtkApplication *app;
	int status;

	// create a threaded application
	app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
	g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
	// run the application -> emits an "activate" signal
	status = g_application_run (G_APPLICATION (app), argc, argv);
	g_object_unref (app);

	return status;
}

